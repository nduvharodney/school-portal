"use client"

import { database } from "./firebase"
import { ref, set, get, onValue, off, remove } from "firebase/database"
import { enhancedLocalSync } from "./enhanced-local-sync"

interface Student {
  id: string
  firstName: string
  lastName: string
  fullName: string
  username: string
  password: string
  dateOfBirth: string
  gender: string
  contactNumber: string
  address: string
  form: string
  guardianFirstName: string
  guardianLastName: string
  relationship: string
  guardianIdNo: string
  guardianContact: string
  guardianAddress: string
  profileImage: string
  teacherComment?: string
  headComment?: string
  pastorComment?: string
  createdAt: string
}

interface Mark {
  id: string
  studentId: string
  year: string
  session: string
  subject: string
  mark: number
  grade: string
  comment: string
  createdAt: string
}

class FirebaseSync {
  private static instance: FirebaseSync
  private listeners: Map<string, Set<(data: any) => void>> = new Map()
  private deviceId = ""
  private syncCode = "ELIM2025"
  private isClient = false
  private firebaseAvailable = false

  private constructor() {
    if (typeof window !== "undefined") {
      this.isClient = true
      this.deviceId = this.generateDeviceId()
      this.checkFirebaseAvailability()
      console.log("🔥 Firebase sync initialized with device ID:", this.deviceId)
    }
  }

  static getInstance(): FirebaseSync {
    if (!FirebaseSync.instance) {
      FirebaseSync.instance = new FirebaseSync()
    }
    return FirebaseSync.instance
  }

  private checkFirebaseAvailability() {
    this.firebaseAvailable = database !== null && database !== undefined

    if (this.firebaseAvailable) {
      console.log("✅ Firebase Realtime Database is available")
    } else {
      console.warn("⚠️ Firebase Realtime Database not available, using enhanced localStorage")
    }
  }

  private generateDeviceId(): string {
    if (!this.isClient) return ""

    let deviceId = localStorage.getItem("elim-device-id")
    if (!deviceId) {
      deviceId = `device_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
      localStorage.setItem("elim-device-id", deviceId)
    }
    return deviceId
  }

  // Subscribe to data changes
  subscribe(type: string, callback: (data: any) => void) {
    if (!this.isClient) return () => {}

    if (!this.listeners.has(type)) {
      this.listeners.set(type, new Set())
    }
    this.listeners.get(type)!.add(callback)

    if (this.firebaseAvailable) {
      // Use Firebase
      const dataRef = ref(database, `${this.syncCode}/${type}`)

      const unsubscribe = onValue(
        dataRef,
        (snapshot) => {
          const data = snapshot.val()
          console.log(`🔥 Firebase: Received ${type} data:`, data ? Object.keys(data).length : 0, "items")

          if (data) {
            const dataArray = Object.values(data)
            callback(dataArray)
          } else {
            callback([])
          }
        },
        (error) => {
          console.error(`🔥 Firebase: Error listening to ${type}:`, error)
          // Fallback to enhanced localStorage
          this.fallbackToLocalStorage(type, callback)
        },
      )

      return () => {
        this.listeners.get(type)?.delete(callback)
        off(dataRef, "value", unsubscribe)
      }
    } else {
      // Use enhanced localStorage
      return enhancedLocalSync.subscribe(type, callback)
    }
  }

  private fallbackToLocalStorage(type: string, callback: (data: any) => void) {
    console.log(`📱 Falling back to enhanced localStorage for ${type}`)
    enhancedLocalSync.subscribe(type, callback)
  }

  // Save data
  async saveData(type: string, data: any[]): Promise<void> {
    if (!this.isClient) return

    if (this.firebaseAvailable) {
      try {
        console.log(`🔥 Firebase: Saving ${type} data (${data.length} items)`)

        const dataRef = ref(database, `${this.syncCode}/${type}`)
        const dataObject: any = {}
        data.forEach((item) => {
          if (item.id) {
            dataObject[item.id] = item
          }
        })

        await set(dataRef, dataObject)
        console.log(`✅ Firebase: ${type} data saved successfully`)
      } catch (error) {
        console.error(`❌ Firebase: Error saving ${type} data:`, error)
        console.log(`📱 Falling back to enhanced localStorage`)
        await enhancedLocalSync.saveData(type, data)
      }
    } else {
      await enhancedLocalSync.saveData(type, data)
    }
  }

  // Get data
  async getData(type: string): Promise<any[]> {
    if (!this.isClient) return []

    if (this.firebaseAvailable) {
      try {
        console.log(`🔥 Firebase: Getting ${type} data`)

        const dataRef = ref(database, `${this.syncCode}/${type}`)
        const snapshot = await get(dataRef)

        if (snapshot.exists()) {
          const data = snapshot.val()
          const dataArray = Object.values(data)
          console.log(`✅ Firebase: Retrieved ${type} data (${dataArray.length} items)`)
          return dataArray as any[]
        } else {
          console.log(`📭 Firebase: No ${type} data found`)
          return []
        }
      } catch (error) {
        console.error(`❌ Firebase: Error getting ${type} data:`, error)
        console.log(`📱 Falling back to enhanced localStorage`)
        return await enhancedLocalSync.getData(type)
      }
    } else {
      return await enhancedLocalSync.getData(type)
    }
  }

  // Add single item
  async addItem(type: string, item: any): Promise<void> {
    if (!this.isClient) return

    if (this.firebaseAvailable) {
      try {
        console.log(`🔥 Firebase: Adding ${type} item:`, item.id)

        const itemRef = ref(database, `${this.syncCode}/${type}/${item.id}`)
        await set(itemRef, item)

        console.log(`✅ Firebase: ${type} item added successfully`)
      } catch (error) {
        console.error(`❌ Firebase: Error adding ${type} item:`, error)
        await enhancedLocalSync.addItem(type, item)
      }
    } else {
      await enhancedLocalSync.addItem(type, item)
    }
  }

  // Update single item
  async updateItem(type: string, itemId: string, updates: any): Promise<void> {
    if (!this.isClient) return

    if (this.firebaseAvailable) {
      try {
        console.log(`🔥 Firebase: Updating ${type} item:`, itemId)

        const itemRef = ref(database, `${this.syncCode}/${type}/${itemId}`)
        const snapshot = await get(itemRef)

        if (snapshot.exists()) {
          const currentData = snapshot.val()
          const updatedData = { ...currentData, ...updates }
          await set(itemRef, updatedData)
          console.log(`✅ Firebase: ${type} item updated successfully`)
        } else {
          console.warn(`⚠️ Firebase: ${type} item ${itemId} not found for update`)
        }
      } catch (error) {
        console.error(`❌ Firebase: Error updating ${type} item:`, error)
        await enhancedLocalSync.updateItem(type, itemId, updates)
      }
    } else {
      await enhancedLocalSync.updateItem(type, itemId, updates)
    }
  }

  // Delete single item
  async deleteItem(type: string, itemId: string): Promise<void> {
    if (!this.isClient) return

    if (this.firebaseAvailable) {
      try {
        console.log(`🔥 Firebase: Deleting ${type} item:`, itemId)

        const itemRef = ref(database, `${this.syncCode}/${type}/${itemId}`)
        await remove(itemRef)

        console.log(`✅ Firebase: ${type} item deleted successfully`)
      } catch (error) {
        console.error(`❌ Firebase: Error deleting ${type} item:`, error)
        await enhancedLocalSync.deleteItem(type, itemId)
      }
    } else {
      await enhancedLocalSync.deleteItem(type, itemId)
    }
  }

  // Get sync info
  getSyncInfo() {
    const baseInfo = {
      deviceId: this.deviceId,
      syncCode: this.syncCode,
      connectedDevices: 1,
      isOnline: typeof window !== "undefined" ? navigator.onLine : false,
    }

    if (this.firebaseAvailable) {
      return {
        ...baseInfo,
        backend: "Firebase Realtime Database",
        status: "Connected",
      }
    } else {
      return {
        ...baseInfo,
        backend: "Enhanced LocalStorage + BroadcastChannel",
        status: "Local Mode",
      }
    }
  }

  // Force sync
  async forceSync(): Promise<void> {
    if (!this.isClient) return

    if (this.firebaseAvailable) {
      try {
        console.log("🔄 Firebase: Force syncing...")

        const students = await this.getData("students")
        const marks = await this.getData("marks")

        this.notifyListeners("students", students)
        this.notifyListeners("marks", marks)

        console.log("✅ Firebase: Force sync completed")
      } catch (error) {
        console.error("❌ Firebase: Force sync failed:", error)
        await enhancedLocalSync.forceSync()
      }
    } else {
      await enhancedLocalSync.forceSync()
    }
  }

  private notifyListeners(type: string, data: any) {
    const listeners = this.listeners.get(type)
    if (listeners && data) {
      console.log(`🔔 Notifying ${listeners.size} listeners for ${type}`)
      listeners.forEach((callback) => {
        try {
          callback(data)
        } catch (error) {
          console.error("Error in listener callback:", error)
        }
      })
    }
  }
}

// Export singleton instance
export const firebaseSync = FirebaseSync.getInstance()
