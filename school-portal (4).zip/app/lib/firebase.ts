// Firebase configuration and initialization
import { initializeApp } from "firebase/app"
import { getDatabase } from "firebase/database"
import { getAuth } from "firebase/auth"

// Demo Firebase configuration - replace with your actual config
const firebaseConfig = {
  apiKey: "demo-api-key",
  authDomain: "elim-college-portal.firebaseapp.com",
  databaseURL: "https://elim-college-portal-default-rtdb.firebaseio.com/",
  projectId: "elim-college-portal",
  storageBucket: "elim-college-portal.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:demo-app-id",
}

let app: any = null
let database: any = null
let auth: any = null

try {
  // Initialize Firebase
  app = initializeApp(firebaseConfig)

  // Initialize Realtime Database
  database = getDatabase(app)

  // Initialize Auth
  auth = getAuth(app)

  console.log("✅ Firebase initialized successfully")
} catch (error) {
  console.warn("⚠️ Firebase initialization failed:", error)
  console.log("📱 Falling back to localStorage sync")
}

export { database, auth }
export default app
