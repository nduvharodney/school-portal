// Local synchronization system using localStorage and BroadcastChannel
export class LocalSyncManager {
  private static instance: LocalSyncManager
  private channel: BroadcastChannel
  private listeners: Map<string, Set<(data: any) => void>> = new Map()

  private constructor() {
    // Create a broadcast channel for cross-tab communication
    this.channel = new BroadcastChannel("elim-college-sync")

    // Listen for messages from other tabs/windows
    this.channel.addEventListener("message", (event) => {
      const { type, data } = event.data
      this.notifyListeners(type, data)
    })
  }

  static getInstance(): LocalSyncManager {
    if (!LocalSyncManager.instance) {
      LocalSyncManager.instance = new LocalSyncManager()
    }
    return LocalSyncManager.instance
  }

  // Subscribe to data changes
  subscribe(type: string, callback: (data: any) => void) {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, new Set())
    }
    this.listeners.get(type)!.add(callback)

    // Return unsubscribe function
    return () => {
      this.listeners.get(type)?.delete(callback)
    }
  }

  // Broadcast data change to all tabs/windows
  broadcast(type: string, data: any) {
    // Save to localStorage
    const storageKey = `elim-college-${type}`
    localStorage.setItem(
      storageKey,
      JSON.stringify({
        data,
        timestamp: Date.now(),
        id: Math.random().toString(36).substring(7),
      }),
    )

    // Broadcast to other tabs
    this.channel.postMessage({ type, data })

    // Notify local listeners
    this.notifyListeners(type, data)
  }

  // Get data from localStorage
  getData(type: string): any {
    const storageKey = `elim-college-${type}`
    const stored = localStorage.getItem(storageKey)
    if (stored) {
      try {
        return JSON.parse(stored).data
      } catch (error) {
        console.error("Error parsing stored data:", error)
        return null
      }
    }
    return null
  }

  // Notify all listeners of a data change
  private notifyListeners(type: string, data: any) {
    const listeners = this.listeners.get(type)
    if (listeners) {
      listeners.forEach((callback) => {
        try {
          callback(data)
        } catch (error) {
          console.error("Error in listener callback:", error)
        }
      })
    }
  }

  // Simulate network delay for realistic sync experience
  private async simulateNetworkDelay() {
    const delay = Math.random() * 500 + 200 // 200-700ms delay
    await new Promise((resolve) => setTimeout(resolve, delay))
  }

  // Enhanced broadcast with network simulation
  async broadcastWithDelay(type: string, data: any) {
    await this.simulateNetworkDelay()
    this.broadcast(type, data)
  }
}

// Export singleton instance
export const syncManager = LocalSyncManager.getInstance()
