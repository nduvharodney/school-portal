"use client"

interface Student {
  id: string
  firstName: string
  lastName: string
  fullName: string
  username: string
  password: string
  dateOfBirth: string
  gender: string
  contactNumber: string
  address: string
  form: string
  guardianFirstName: string
  guardianLastName: string
  relationship: string
  guardianIdNo: string
  guardianContact: string
  guardianAddress: string
  profileImage: string
  teacherComment?: string
  headComment?: string
  pastorComment?: string
  createdAt: string
}

interface Mark {
  id: string
  studentId: string
  year: string
  session: string
  subject: string
  mark: number
  grade: string
  comment: string
  createdAt: string
}

interface SyncData {
  students: Student[]
  marks: Mark[]
  lastUpdated: string
  deviceId: string
  syncCode: string
}

class EnhancedLocalSync {
  private static instance: EnhancedLocalSync
  private listeners: Map<string, Set<(data: any) => void>> = new Map()
  private deviceId = ""
  private syncCode = "ELIM2025"
  private isClient = false
  private syncInterval: NodeJS.Timeout | null = null
  private broadcastChannel: BroadcastChannel | null = null

  private constructor() {
    if (typeof window !== "undefined") {
      this.isClient = true
      this.deviceId = this.generateDeviceId()
      this.initializeBroadcastChannel()
      this.startAutoSync()
      console.log("🔄 Enhanced Local Sync initialized with device ID:", this.deviceId)
    }
  }

  static getInstance(): EnhancedLocalSync {
    if (!EnhancedLocalSync.instance) {
      EnhancedLocalSync.instance = new EnhancedLocalSync()
    }
    return EnhancedLocalSync.instance
  }

  private generateDeviceId(): string {
    if (!this.isClient) return ""

    let deviceId = localStorage.getItem("elim-device-id")
    if (!deviceId) {
      deviceId = `device_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
      localStorage.setItem("elim-device-id", deviceId)
    }
    return deviceId
  }

  private initializeBroadcastChannel() {
    if (!this.isClient) return

    try {
      this.broadcastChannel = new BroadcastChannel(`elim-sync-${this.syncCode}`)

      this.broadcastChannel.onmessage = (event) => {
        const { type, data, deviceId } = event.data

        // Don't process messages from the same device
        if (deviceId === this.deviceId) return

        console.log(`📡 Received broadcast: ${type} from device ${deviceId}`)

        if (type === "data-update") {
          this.handleRemoteDataUpdate(data)
        }
      }

      console.log("📡 BroadcastChannel initialized")
    } catch (error) {
      console.warn("⚠️ BroadcastChannel not supported:", error)
    }
  }

  private handleRemoteDataUpdate(data: any) {
    console.log("🔄 Processing remote data update")

    // Update local storage with remote data
    if (data.students) {
      localStorage.setItem(`${this.syncCode}-students`, JSON.stringify(data.students))
      this.notifyListeners("students", data.students)
    }

    if (data.marks) {
      localStorage.setItem(`${this.syncCode}-marks`, JSON.stringify(data.marks))
      this.notifyListeners("marks", data.marks)
    }
  }

  private startAutoSync() {
    if (!this.isClient) return

    // Sync every 5 seconds
    this.syncInterval = setInterval(() => {
      this.performAutoSync()
    }, 5000)

    console.log("⏰ Auto-sync started (5 second intervals)")
  }

  private async performAutoSync() {
    try {
      // Check if there are any updates from other devices
      const lastSyncTime = localStorage.getItem(`${this.syncCode}-last-sync`) || "0"
      const currentTime = Date.now().toString()

      // Get current data
      const students = await this.getData("students")
      const marks = await this.getData("marks")

      // Update last sync time
      localStorage.setItem(`${this.syncCode}-last-sync`, currentTime)

      // Broadcast current state to other tabs/windows
      this.broadcastUpdate("students", students)
      this.broadcastUpdate("marks", marks)
    } catch (error) {
      console.error("❌ Auto-sync error:", error)
    }
  }

  private broadcastUpdate(type: string, data: any) {
    if (!this.broadcastChannel) return

    try {
      this.broadcastChannel.postMessage({
        type: "data-update",
        data: { [type]: data },
        deviceId: this.deviceId,
        timestamp: Date.now(),
      })

      console.log(`📡 Broadcasted ${type} update`)
    } catch (error) {
      console.error("❌ Broadcast error:", error)
    }
  }

  // Subscribe to data changes
  subscribe(type: string, callback: (data: any) => void) {
    if (!this.isClient) return () => {}

    if (!this.listeners.has(type)) {
      this.listeners.set(type, new Set())
    }
    this.listeners.get(type)!.add(callback)

    // Immediately provide current data
    this.getData(type).then((data) => {
      callback(data)
    })

    return () => {
      this.listeners.get(type)?.delete(callback)
    }
  }

  // Save data to localStorage
  async saveData(type: string, data: any[]): Promise<void> {
    if (!this.isClient) return

    try {
      console.log(`💾 Saving ${type} data (${data.length} items)`)

      const key = `${this.syncCode}-${type}`
      const dataWithTimestamp = {
        data,
        lastUpdated: new Date().toISOString(),
        deviceId: this.deviceId,
      }

      localStorage.setItem(key, JSON.stringify(dataWithTimestamp))

      // Broadcast the update
      this.broadcastUpdate(type, data)

      // Notify local listeners
      this.notifyListeners(type, data)

      console.log(`✅ ${type} data saved successfully`)
    } catch (error) {
      console.error(`❌ Error saving ${type} data:`, error)
      throw error
    }
  }

  // Get data from localStorage
  async getData(type: string): Promise<any[]> {
    if (!this.isClient) return []

    try {
      const key = `${this.syncCode}-${type}`
      const stored = localStorage.getItem(key)

      if (stored) {
        const parsed = JSON.parse(stored)
        const data = parsed.data || parsed // Handle both old and new format
        console.log(`📖 Retrieved ${type} data (${data.length} items)`)
        return Array.isArray(data) ? data : []
      } else {
        console.log(`📭 No ${type} data found`)
        return []
      }
    } catch (error) {
      console.error(`❌ Error getting ${type} data:`, error)
      return []
    }
  }

  // Add single item
  async addItem(type: string, item: any): Promise<void> {
    if (!this.isClient) return

    try {
      console.log(`➕ Adding ${type} item:`, item.id)

      const currentData = await this.getData(type)
      const updatedData = [...currentData, item]

      await this.saveData(type, updatedData)

      console.log(`✅ ${type} item added successfully`)
    } catch (error) {
      console.error(`❌ Error adding ${type} item:`, error)
      throw error
    }
  }

  // Update single item
  async updateItem(type: string, itemId: string, updates: any): Promise<void> {
    if (!this.isClient) return

    try {
      console.log(`✏️ Updating ${type} item:`, itemId)

      const currentData = await this.getData(type)
      const updatedData = currentData.map((item) => (item.id === itemId ? { ...item, ...updates } : item))

      await this.saveData(type, updatedData)

      console.log(`✅ ${type} item updated successfully`)
    } catch (error) {
      console.error(`❌ Error updating ${type} item:`, error)
      throw error
    }
  }

  // Delete single item
  async deleteItem(type: string, itemId: string): Promise<void> {
    if (!this.isClient) return

    try {
      console.log(`🗑️ Deleting ${type} item:`, itemId)

      const currentData = await this.getData(type)
      const updatedData = currentData.filter((item) => item.id !== itemId)

      await this.saveData(type, updatedData)

      console.log(`✅ ${type} item deleted successfully`)
    } catch (error) {
      console.error(`❌ Error deleting ${type} item:`, error)
      throw error
    }
  }

  // Get sync info
  getSyncInfo() {
    return {
      deviceId: this.deviceId,
      syncCode: this.syncCode,
      connectedDevices: 1,
      isOnline: typeof window !== "undefined" ? navigator.onLine : false,
      backend: "Enhanced LocalStorage + BroadcastChannel",
      autoSync: this.syncInterval !== null,
      broadcastSupported: this.broadcastChannel !== null,
    }
  }

  // Force sync (refresh data)
  async forceSync(): Promise<void> {
    if (!this.isClient) return

    try {
      console.log("🔄 Force syncing...")

      // Get fresh data
      const students = await this.getData("students")
      const marks = await this.getData("marks")

      // Notify listeners
      this.notifyListeners("students", students)
      this.notifyListeners("marks", marks)

      // Broadcast updates
      this.broadcastUpdate("students", students)
      this.broadcastUpdate("marks", marks)

      console.log("✅ Force sync completed")
    } catch (error) {
      console.error("❌ Force sync failed:", error)
      throw error
    }
  }

  private notifyListeners(type: string, data: any) {
    const listeners = this.listeners.get(type)
    if (listeners && data) {
      console.log(`🔔 Notifying ${listeners.size} listeners for ${type}`)
      listeners.forEach((callback) => {
        try {
          callback(data)
        } catch (error) {
          console.error("Error in listener callback:", error)
        }
      })
    }
  }

  // Cleanup
  destroy() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval)
      this.syncInterval = null
    }

    if (this.broadcastChannel) {
      this.broadcastChannel.close()
      this.broadcastChannel = null
    }

    this.listeners.clear()
    console.log("🧹 Enhanced Local Sync destroyed")
  }
}

// Export singleton instance
export const enhancedLocalSync = EnhancedLocalSync.getInstance()
