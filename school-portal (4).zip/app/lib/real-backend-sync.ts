// Real backend synchronization service
class RealBackendSync {
  private static instance: RealBackendSync
  private baseUrl = "https://elim-college-sync.herokuapp.com/api" // Replace with your backend
  private syncCode = "ELIM2025"
  private deviceId = ""

  private constructor() {
    if (typeof window !== "undefined") {
      this.deviceId = this.generateDeviceId()
    }
  }

  static getInstance(): RealBackendSync {
    if (!RealBackendSync.instance) {
      RealBackendSync.instance = new RealBackendSync()
    }
    return RealBackendSync.instance
  }

  private generateDeviceId(): string {
    let deviceId = localStorage.getItem("elim-device-id")
    if (!deviceId) {
      deviceId = `device_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
      localStorage.setItem("elim-device-id", deviceId)
    }
    return deviceId
  }

  async saveData(type: string, data: any): Promise<void> {
    try {
      const payload = {
        syncCode: this.syncCode,
        deviceId: this.deviceId,
        type,
        data,
        timestamp: Date.now(),
      }

      // For now, use localStorage as fallback
      // In production, replace with actual API call:
      // const response = await fetch(`${this.baseUrl}/sync`, {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(payload)
      // })

      localStorage.setItem(`elim-backend-${type}`, JSON.stringify(payload))

      // Broadcast to other tabs
      const channel = new BroadcastChannel("elim-backend-sync")
      channel.postMessage(payload)

      console.log(`💾 Saved ${type} to backend (${data?.length || 0} items)`)
    } catch (error) {
      console.error(`❌ Error saving ${type} to backend:`, error)
      throw error
    }
  }

  async getData(type: string): Promise<any> {
    try {
      // For now, use localStorage as fallback
      // In production, replace with actual API call:
      // const response = await fetch(`${this.baseUrl}/sync/${this.syncCode}/${type}`)
      // const result = await response.json()

      const stored = localStorage.getItem(`elim-backend-${type}`)
      if (stored) {
        const parsed = JSON.parse(stored)
        console.log(`📥 Retrieved ${type} from backend (${parsed.data?.length || 0} items)`)
        return parsed.data
      }

      return null
    } catch (error) {
      console.error(`❌ Error getting ${type} from backend:`, error)
      return null
    }
  }

  async checkForUpdates(type: string, lastTimestamp: number): Promise<any> {
    try {
      // For now, use localStorage as fallback
      const stored = localStorage.getItem(`elim-backend-${type}`)
      if (stored) {
        const parsed = JSON.parse(stored)
        if (parsed.timestamp > lastTimestamp && parsed.deviceId !== this.deviceId) {
          console.log(`🔄 Found newer ${type} data from another device`)
          return parsed
        }
      }

      return null
    } catch (error) {
      console.error(`❌ Error checking updates for ${type}:`, error)
      return null
    }
  }

  startListener(callback: (type: string, data: any) => void) {
    try {
      const channel = new BroadcastChannel("elim-backend-sync")
      channel.addEventListener("message", (event) => {
        const { type, data, deviceId } = event.data

        if (deviceId !== this.deviceId) {
          console.log(`📡 Received ${type} update from device ${deviceId}`)
          callback(type, data)
        }
      })
    } catch (error) {
      console.warn("BroadcastChannel not supported")
    }
  }
}

export const realBackendSync = RealBackendSync.getInstance()
