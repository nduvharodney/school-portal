"use client"

import { useState, useEffect } from "react"
import { useUniversalStudentStore } from "../store/universal-student-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Users, Search, Trash2, Eye, UserX } from "lucide-react"

export function ManageStudents() {
  const { students, marks, deleteStudent } = useUniversalStudentStore()

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStudent, setSelectedStudent] = useState<any>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  // Initialize store on component mount
  useEffect(() => {
    // Store should already be initialized
  }, [])

  // Filter students based on search term
  const filteredStudents = students.filter(
    (student) =>
      student.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.form.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.username.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleDeleteStudent = async (studentId: string, studentName: string) => {
    if (
      !confirm(
        `Are you sure you want to delete ${studentName}? This will also delete all their marks and cannot be undone.`,
      )
    ) {
      return
    }

    setIsDeleting(true)
    try {
      await deleteStudent(studentId)
      alert("Student deleted successfully!")
      setSelectedStudent(null)
    } catch (error) {
      console.error("Error deleting student:", error)
      alert("Failed to delete student. Please try again.")
    } finally {
      setIsDeleting(false)
    }
  }

  const getStudentMarksCount = (studentId: string) => {
    return marks.filter((mark) => mark.studentId === studentId).length
  }

  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Manage Students
        </CardTitle>
        <div className="flex items-center gap-4 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{students.length} Total Students</span>
          </div>
          <div className="flex items-center gap-1">
            <Search className="h-4 w-4" />
            <span>{filteredStudents.length} Showing</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search students by name, form, or username..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Students List */}
        {filteredStudents.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredStudents.map((student) => (
              <Card key={student.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <img
                      src={student.profileImage || "/placeholder.svg"}
                      alt={student.fullName}
                      className="w-12 h-12 rounded-full object-cover border-2 border-gray-200"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold truncate">{student.fullName}</h3>
                      <p className="text-sm text-gray-600">{student.form}</p>
                      <p className="text-xs text-gray-500">@{student.username}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="secondary" className="text-xs">
                          {getStudentMarksCount(student.id)} marks
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {student.gender}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 mt-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 bg-transparent"
                          onClick={() => setSelectedStudent(student)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>Student Details</DialogTitle>
                        </DialogHeader>
                        {selectedStudent && (
                          <div className="space-y-6">
                            {/* Student Info */}
                            <div className="flex items-center gap-4">
                              <img
                                src={selectedStudent.profileImage || "/placeholder.svg"}
                                alt={selectedStudent.fullName}
                                className="w-20 h-20 rounded-full object-cover border-4 border-gray-200"
                              />
                              <div>
                                <h3 className="text-xl font-semibold">{selectedStudent.fullName}</h3>
                                <p className="text-gray-600">{selectedStudent.form}</p>
                                <p className="text-sm text-gray-500">Username: {selectedStudent.username}</p>
                                <p className="text-sm text-gray-500">Password: {selectedStudent.password}</p>
                              </div>
                            </div>

                            {/* Personal Details */}
                            <div>
                              <h4 className="font-semibold mb-3">Personal Information</h4>
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                  <strong>Date of Birth:</strong> {selectedStudent.dateOfBirth || "Not provided"}
                                </div>
                                <div>
                                  <strong>Gender:</strong> {selectedStudent.gender || "Not provided"}
                                </div>
                                <div>
                                  <strong>Contact:</strong> {selectedStudent.contactNumber || "Not provided"}
                                </div>
                                <div>
                                  <strong>Address:</strong> {selectedStudent.address || "Not provided"}
                                </div>
                              </div>
                            </div>

                            {/* Guardian Details */}
                            <div>
                              <h4 className="font-semibold mb-3">Guardian Information</h4>
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                  <strong>Name:</strong> {selectedStudent.guardianFirstName}{" "}
                                  {selectedStudent.guardianLastName}
                                </div>
                                <div>
                                  <strong>Relationship:</strong> {selectedStudent.relationship || "Not provided"}
                                </div>
                                <div>
                                  <strong>ID Number:</strong> {selectedStudent.guardianIdNo || "Not provided"}
                                </div>
                                <div>
                                  <strong>Contact:</strong> {selectedStudent.guardianContact || "Not provided"}
                                </div>
                                <div className="col-span-2">
                                  <strong>Address:</strong> {selectedStudent.guardianAddress || "Not provided"}
                                </div>
                              </div>
                            </div>

                            {/* Academic Info */}
                            <div>
                              <h4 className="font-semibold mb-3">Academic Information</h4>
                              <div className="text-sm">
                                <p>
                                  <strong>Total Marks:</strong> {getStudentMarksCount(selectedStudent.id)}
                                </p>
                                <p>
                                  <strong>Created:</strong> {new Date(selectedStudent.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>

                            {/* Delete Button */}
                            <div className="pt-4 border-t">
                              <Button
                                variant="destructive"
                                onClick={() => handleDeleteStudent(selectedStudent.id, selectedStudent.fullName)}
                                disabled={isDeleting}
                                className="w-full"
                              >
                                <UserX className="h-4 w-4 mr-2" />
                                {isDeleting ? "Deleting..." : "Delete Student"}
                              </Button>
                              <p className="text-xs text-gray-500 mt-2 text-center">
                                This will permanently delete the student and all their marks
                              </p>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteStudent(student.id, student.fullName)}
                      disabled={isDeleting}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">
              {searchTerm ? "No students found" : "No students yet"}
            </h3>
            <p className="text-gray-500">
              {searchTerm
                ? `No students match "${searchTerm}". Try a different search term.`
                : "Add your first student to get started."}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
