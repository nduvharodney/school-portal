"use client"

import { useEffect, useState } from "react"
import { useUniversalStudentStore } from "../store/universal-student-store"
import { firebaseSync } from "../lib/firebase-sync"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { RefreshCw, Wifi, WifiOff, Database, Users, BookOpen, Clock, AlertCircle } from "lucide-react"

export function UniversalSyncStatus() {
  const { students, marks, syncStatus, lastSyncTime, error, forceSync, clearError, isLoading } =
    useUniversalStudentStore()

  const [syncInfo, setSyncInfo] = useState<any>({})
  const [isOnline, setIsOnline] = useState(true)

  useEffect(() => {
    // Get sync info
    const info = firebaseSync.getSyncInfo()
    setSyncInfo(info)

    // Monitor online status
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    if (typeof window !== "undefined") {
      setIsOnline(navigator.onLine)
      window.addEventListener("online", handleOnline)
      window.addEventListener("offline", handleOffline)

      return () => {
        window.removeEventListener("online", handleOnline)
        window.removeEventListener("offline", handleOffline)
      }
    }
  }, [])

  const getStatusColor = () => {
    if (error) return "destructive"
    if (isLoading) return "secondary"
    if (syncStatus.includes("successfully") || syncStatus === "Connected") return "default"
    return "secondary"
  }

  const getStatusIcon = () => {
    if (error) return <AlertCircle className="h-4 w-4" />
    if (!isOnline) return <WifiOff className="h-4 w-4" />
    if (syncInfo.backend?.includes("Firebase")) return <Database className="h-4 w-4" />
    return <Wifi className="h-4 w-4" />
  }

  return (
    <Card className="w-full">
      <CardContent className="p-4">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getStatusIcon()}
              <h3 className="font-semibold">Sync Status</h3>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={forceSync}
              disabled={isLoading}
              className="flex items-center gap-2 bg-transparent"
            >
              <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
              Sync
            </Button>
          </div>

          {/* Status Badge */}
          <div className="flex items-center gap-2">
            <Badge variant={getStatusColor()}>{syncStatus}</Badge>
            {!isOnline && <Badge variant="destructive">Offline</Badge>}
          </div>

          {/* Error Display */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-500" />
                  <span className="text-sm text-red-700">{error}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={clearError} className="text-red-500 hover:text-red-700">
                  ×
                </Button>
              </div>
            </div>
          )}

          {/* Data Counters */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg">
              <Users className="h-4 w-4 text-blue-600" />
              <div>
                <div className="text-sm font-medium">{students.length}</div>
                <div className="text-xs text-gray-500">Students</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg">
              <BookOpen className="h-4 w-4 text-green-600" />
              <div>
                <div className="text-sm font-medium">{marks.length}</div>
                <div className="text-xs text-gray-500">Marks</div>
              </div>
            </div>
          </div>

          {/* Sync Info */}
          <div className="space-y-2 text-xs text-gray-500">
            <div className="flex items-center gap-2">
              <Clock className="h-3 w-3" />
              <span>Last sync: {lastSyncTime || "Never"}</span>
            </div>
            <div>Backend: {syncInfo.backend || "Loading..."}</div>
            <div>Device: {syncInfo.deviceId?.substring(0, 12)}...</div>
            <div>Code: {syncInfo.syncCode}</div>
            {syncInfo.status && <div>Status: {syncInfo.status}</div>}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
