"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Wifi, WifiOff, RefreshCw, Zap, ZapOff, CheckCircle, AlertCircle, Clock } from "lucide-react"
import { useRealtimeStudentStore } from "../store/realtime-student-store"

export default function RealtimeSyncStatus() {
  const { isOnline, isSyncing, lastSyncTime, students, marks, syncStatus, forceSync, initializeSync } =
    useRealtimeStudentStore()

  const [showDetails, setShowDetails] = useState(false)

  useEffect(() => {
    // Initialize sync when component mounts
    initializeSync()
  }, [initializeSync])

  const handleForceSync = async () => {
    try {
      await forceSync()
    } catch (error) {
      console.error("Force sync failed:", error)
    }
  }

  const getSyncStatusIcon = () => {
    switch (syncStatus) {
      case "syncing":
        return <RefreshCw className="w-5 h-5 text-blue-600 animate-spin" />
      case "connected":
        return <Zap className="w-5 h-5 text-green-600" />
      case "offline":
        return <ZapOff className="w-5 h-5 text-gray-600" />
      case "error":
        return <AlertCircle className="w-5 h-5 text-red-600" />
      default:
        return <Clock className="w-5 h-5 text-yellow-600" />
    }
  }

  const getSyncStatusText = () => {
    switch (syncStatus) {
      case "syncing":
        return "Syncing..."
      case "connected":
        return "Real-time Sync Active"
      case "offline":
        return "Offline Mode"
      case "error":
        return "Sync Error"
      default:
        return "Connecting..."
    }
  }

  const getSyncStatusColor = () => {
    switch (syncStatus) {
      case "syncing":
        return "text-blue-700"
      case "connected":
        return "text-green-700"
      case "offline":
        return "text-gray-700"
      case "error":
        return "text-red-700"
      default:
        return "text-yellow-700"
    }
  }

  return (
    <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Online Status */}
            <div className="flex items-center gap-2">
              {isOnline ? <Wifi className="w-5 h-5 text-green-600" /> : <WifiOff className="w-5 h-5 text-red-600" />}
              <span className={`text-sm font-medium ${isOnline ? "text-green-700" : "text-red-700"}`}>
                {isOnline ? "Online" : "Offline"}
              </span>
            </div>

            {/* Sync Status */}
            <div className="flex items-center gap-2">
              {getSyncStatusIcon()}
              <span className={`text-sm font-medium ${getSyncStatusColor()}`}>{getSyncStatusText()}</span>
            </div>

            {/* Data Count */}
            <div className="flex items-center gap-4 text-xs text-gray-600">
              <span>{students.length} Students</span>
              <span>{marks.length} Marks</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowDetails(!showDetails)} className="text-xs">
              {showDetails ? "Hide" : "Details"}
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={handleForceSync}
              disabled={isSyncing}
              className="text-xs bg-transparent"
            >
              <RefreshCw className={`w-3 h-3 mr-1 ${isSyncing ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        {showDetails && (
          <div className="mt-3 pt-3 border-t border-green-200">
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <div className="font-medium text-gray-700">Sync Status</div>
                <div className={`flex items-center gap-1 ${getSyncStatusColor()}`}>
                  {syncStatus === "connected" ? (
                    <CheckCircle className="w-3 h-3" />
                  ) : (
                    <AlertCircle className="w-3 h-3" />
                  )}
                  {syncStatus === "connected" ? "All devices synchronized" : "Limited functionality"}
                </div>
              </div>
              <div>
                <div className="font-medium text-gray-700">Last Update</div>
                <div className="text-gray-600">{lastSyncTime || "Never"}</div>
              </div>
            </div>

            <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded text-xs text-green-800">
              <strong>Real-time Sync:</strong> Changes appear on all devices instantly using local network
              synchronization.
            </div>

            {syncStatus === "offline" && (
              <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-800">
                <strong>Offline Mode:</strong> Changes are saved locally and will sync when connection is restored.
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
