"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useUniversalStudentStore } from "../store/universal-student-store"

interface StudentLoginProps {
  onLogin: (student: any) => void
  onBackToMain: () => void
}

export default function StudentLogin({ onLogin, onBackToMain }: StudentLoginProps) {
  const { students } = useUniversalStudentStore()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleLogin = () => {
    if (!username || !password) {
      setError("Please enter both username and password")
      return
    }

    const student = students.find((s) => s.username.toLowerCase() === username.toLowerCase() && s.password === password)

    if (student) {
      onLogin(student)
    } else {
      setError("Invalid username or password. Please check your credentials.")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleLogin()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <img src="/images/school-logo.png" alt="ELIM CHRISTAIN COLLEGE Logo" className="w-20 h-20 object-contain" />
          </div>
          <CardTitle className="text-2xl text-white">Student Portal</CardTitle>
          <CardDescription className="text-blue-200">Access Your Academic Reports</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert className="bg-red-500/20 border-red-500/50">
              <AlertDescription className="text-white">{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="username" className="text-white">
              Student ID
            </Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyPress={handleKeyPress}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              placeholder="Enter your student ID"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white">
              Password
            </Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={handleKeyPress}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              placeholder="Enter your password"
            />
          </div>

          <Button onClick={handleLogin} className="w-full bg-purple-600 hover:bg-purple-700">
            Access My Reports
          </Button>

          <div className="text-center">
            <Button variant="ghost" onClick={onBackToMain} className="text-white/70 hover:text-white">
              ← Back to Main Login
            </Button>
          </div>

          <div className="bg-white/10 rounded p-3 mt-4">
            <p className="text-white/80 text-sm text-center">
              <strong>Note:</strong> Use the Student ID and Password provided by your school administration.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
