"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuthStore } from "../store/auth-store"

interface LoginProps {
  onLogin: (authenticated: boolean) => void
  onRoleSet: (role: string) => void
  onStudentPortal: () => void
}

export default function Login({ onLogin, onRoleSet, onStudentPortal }: LoginProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleLogin = () => {
    const { users, validateUser } = useAuthStore.getState()
    const user = validateUser(username, password)

    if (user) {
      onRoleSet(user.role)
      onLogin(true)
    } else {
      setError("Invalid username or password")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <img src="/images/school-logo.png" alt="ELIM CHRISTAIN COLLEGE Logo" className="w-20 h-20 object-contain" />
          </div>
          <CardTitle className="text-2xl text-white">ELIM CHRISTAIN COLLEGE</CardTitle>
          <CardDescription className="text-blue-200">School Management Portal</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert className="bg-red-500/20 border-red-500/50">
              <AlertDescription className="text-white">{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="username" className="text-white">
              Username
            </Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              placeholder="Enter username"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white">
              Password
            </Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              placeholder="Enter password"
            />
          </div>

          <Button onClick={handleLogin} className="w-full bg-purple-600 hover:bg-purple-700">
            Login as Staff
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-white/20" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-transparent px-2 text-white/60">Or</span>
            </div>
          </div>

          <Button
            onClick={onStudentPortal}
            variant="outline"
            className="w-full bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            Student Portal
          </Button>

          <div className="bg-white/10 rounded p-3 mt-4">
            <p className="text-white/80 text-sm text-center">
              <strong>Students:</strong> Use your Student ID and Password to access your reports.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
