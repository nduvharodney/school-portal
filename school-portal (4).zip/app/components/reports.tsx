"use client"

import { useState, useEffect } from "react"
import { useUniversalStudentStore } from "../store/universal-student-store"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { FileText, Printer, Users, BookOpen, Edit3, Save, X } from "lucide-react"

const sessions = ["First Term", "Second Term", "Third Term"]
const currentYear = new Date().getFullYear().toString()

export function Reports() {
  const { students, marks, updateStudent } = useUniversalStudentStore()

  const [selectedStudent, setSelectedStudent] = useState("")
  const [selectedSession, setSelectedSession] = useState("First Term")
  const [selectedYear, setSelectedYear] = useState(currentYear)
  const [teacherComment, setTeacherComment] = useState("")
  const [headComment, setHeadComment] = useState("")
  const [pastorComment, setPastorComment] = useState("")
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  // Initialize store on component mount
  useEffect(() => {
    // Store should already be initialized
  }, [])

  const selectedStudentData = students.find((s) => s.id === selectedStudent)

  // Get marks for selected student, session, and year
  const studentMarks = marks.filter(
    (m) => m.studentId === selectedStudent && m.session === selectedSession && m.year === selectedYear,
  )

  // Update comments when student changes
  useEffect(() => {
    if (selectedStudentData) {
      setTeacherComment(selectedStudentData.teacherComment || "")
      setHeadComment(selectedStudentData.headComment || "")
      setPastorComment(selectedStudentData.pastorComment || "")
    }
  }, [selectedStudentData])

  const handleSaveComments = async () => {
    if (!selectedStudent) return

    setIsSaving(true)
    try {
      await updateStudent(selectedStudent, {
        teacherComment,
        headComment,
        pastorComment,
      })
      setIsEditing(false)
      alert("Comments saved successfully!")
    } catch (error) {
      console.error("Error saving comments:", error)
      alert("Failed to save comments. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  const handleCancelEdit = () => {
    if (selectedStudentData) {
      setTeacherComment(selectedStudentData.teacherComment || "")
      setHeadComment(selectedStudentData.headComment || "")
      setPastorComment(selectedStudentData.pastorComment || "")
    }
    setIsEditing(false)
  }

  const calculateAverage = () => {
    if (studentMarks.length === 0) return 0
    const total = studentMarks.reduce((sum, mark) => sum + mark.mark, 0)
    return Math.round(total / studentMarks.length)
  }

  const handlePrint = () => {
    window.print()
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Student Reports
          </CardTitle>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{students.length} Students</span>
            </div>
            <div className="flex items-center gap-1">
              <BookOpen className="h-4 w-4" />
              <span>{marks.length} Marks</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="year">Academic Year</Label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={currentYear}>{currentYear}</SelectItem>
                  <SelectItem value={(Number.parseInt(currentYear) - 1).toString()}>
                    {Number.parseInt(currentYear) - 1}
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="session">Session</Label>
              <Select value={selectedSession} onValueChange={setSelectedSession}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sessions.map((session) => (
                    <SelectItem key={session} value={session}>
                      {session}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="student">Select Student</Label>
              <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a student" />
                </SelectTrigger>
                <SelectContent>
                  {students.map((student) => (
                    <SelectItem key={student.id} value={student.id}>
                      {student.fullName} - {student.form}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={handlePrint} disabled={!selectedStudent || studentMarks.length === 0} className="w-full">
                <Printer className="h-4 w-4 mr-2" />
                Print Report
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Display */}
      {selectedStudentData && (
        <div className="print:shadow-none print:border-none">
          <Card className="print:shadow-none print:border-none">
            <CardContent className="p-8 print:p-6">
              {/* School Header */}
              <div className="text-center mb-8 print:mb-6">
                <div className="flex items-center justify-center gap-4 mb-4">
                  <img src="/images/school-logo.png" alt="School Logo" className="w-16 h-16 object-contain" />
                  <div>
                    <h1 className="text-2xl font-bold text-blue-900">ELIM CHRISTAIN COLLEGE</h1>
                    <p className="text-sm text-gray-600">Excellence in Education</p>
                    <p className="text-xs text-gray-500">P.O. Box 123, Education City | Tel: +1234567890</p>
                  </div>
                </div>
                <div className="border-t-2 border-blue-900 pt-2">
                  <h2 className="text-xl font-semibold">STUDENT REPORT CARD</h2>
                  <p className="text-sm">
                    {selectedSession} - {selectedYear}
                  </p>
                </div>
              </div>

              {/* Student Information */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="md:col-span-2">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <strong>Student Name:</strong> {selectedStudentData.fullName}
                    </div>
                    <div>
                      <strong>Form/Class:</strong> {selectedStudentData.form}
                    </div>
                    <div>
                      <strong>Date of Birth:</strong> {selectedStudentData.dateOfBirth}
                    </div>
                    <div>
                      <strong>Gender:</strong> {selectedStudentData.gender}
                    </div>
                    <div>
                      <strong>Session:</strong> {selectedSession}
                    </div>
                    <div>
                      <strong>Academic Year:</strong> {selectedYear}
                    </div>
                  </div>
                </div>
                <div className="flex justify-center">
                  <img
                    src={selectedStudentData.profileImage || "/placeholder.svg"}
                    alt={selectedStudentData.fullName}
                    className="w-24 h-24 rounded-lg object-cover border-2 border-gray-200"
                  />
                </div>
              </div>

              {/* Marks Table */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4">Academic Performance</h3>
                {studentMarks.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="border border-gray-300 px-4 py-2 text-left">Subject</th>
                          <th className="border border-gray-300 px-4 py-2 text-center">Mark</th>
                          <th className="border border-gray-300 px-4 py-2 text-center">Grade</th>
                          <th className="border border-gray-300 px-4 py-2 text-left">Comment</th>
                        </tr>
                      </thead>
                      <tbody>
                        {studentMarks.map((mark) => (
                          <tr key={mark.id}>
                            <td className="border border-gray-300 px-4 py-2">{mark.subject}</td>
                            <td className="border border-gray-300 px-4 py-2 text-center">{mark.mark}</td>
                            <td className="border border-gray-300 px-4 py-2 text-center">
                              <Badge variant="secondary">{mark.grade}</Badge>
                            </td>
                            <td className="border border-gray-300 px-4 py-2">{mark.comment || "-"}</td>
                          </tr>
                        ))}
                        <tr className="bg-blue-50 font-semibold">
                          <td className="border border-gray-300 px-4 py-2">AVERAGE</td>
                          <td className="border border-gray-300 px-4 py-2 text-center">{calculateAverage()}</td>
                          <td className="border border-gray-300 px-4 py-2 text-center">
                            <Badge variant="default">
                              {calculateAverage() > 0
                                ? (() => {
                                    const avg = calculateAverage()
                                    if (avg >= 90) return "A+"
                                    if (avg >= 80) return "A"
                                    if (avg >= 70) return "B+"
                                    if (avg >= 60) return "B"
                                    if (avg >= 50) return "C+"
                                    if (avg >= 40) return "C"
                                    if (avg >= 30) return "D"
                                    return "F"
                                  })()
                                : "-"}
                            </Badge>
                          </td>
                          <td className="border border-gray-300 px-4 py-2">-</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    No marks available for this student in {selectedSession} {selectedYear}
                  </div>
                )}
              </div>

              {/* Comments Section */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Comments</h3>
                  {!isEditing ? (
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(true)} className="print:hidden">
                      <Edit3 className="h-4 w-4 mr-2" />
                      Edit Comments
                    </Button>
                  ) : (
                    <div className="flex gap-2 print:hidden">
                      <Button variant="outline" size="sm" onClick={handleSaveComments} disabled={isSaving}>
                        <Save className="h-4 w-4 mr-2" />
                        {isSaving ? "Saving..." : "Save"}
                      </Button>
                      <Button variant="ghost" size="sm" onClick={handleCancelEdit}>
                        <X className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <Label htmlFor="teacherComment" className="text-sm font-medium">
                      Class Teacher's Comment:
                    </Label>
                    {isEditing ? (
                      <Textarea
                        id="teacherComment"
                        value={teacherComment}
                        onChange={(e) => setTeacherComment(e.target.value)}
                        placeholder="Enter class teacher's comment..."
                        rows={3}
                        className="mt-1"
                      />
                    ) : (
                      <div className="mt-1 p-3 border rounded-md min-h-[80px] bg-gray-50">
                        {teacherComment || "No comment provided"}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="headComment" className="text-sm font-medium">
                      Head Teacher's Comment:
                    </Label>
                    {isEditing ? (
                      <Textarea
                        id="headComment"
                        value={headComment}
                        onChange={(e) => setHeadComment(e.target.value)}
                        placeholder="Enter head teacher's comment..."
                        rows={3}
                        className="mt-1"
                      />
                    ) : (
                      <div className="mt-1 p-3 border rounded-md min-h-[80px] bg-gray-50">
                        {headComment || "No comment provided"}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="pastorComment" className="text-sm font-medium">
                      Pastor's Comment:
                    </Label>
                    {isEditing ? (
                      <Textarea
                        id="pastorComment"
                        value={pastorComment}
                        onChange={(e) => setPastorComment(e.target.value)}
                        placeholder="Enter pastor's comment..."
                        rows={3}
                        className="mt-1"
                      />
                    ) : (
                      <div className="mt-1 p-3 border rounded-md min-h-[80px] bg-gray-50">
                        {pastorComment || "No comment provided"}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="mt-8 pt-6 border-t text-center text-sm text-gray-600">
                <p>This report was generated on {new Date().toLocaleDateString()}</p>
                <p className="mt-2">ELIM CHRISTAIN COLLEGE - Nurturing Excellence in Christian Education</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
