"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { User, Search } from "lucide-react"
import { useUniversalStudentStore } from "../store/universal-student-store"

const subjects = [
  "MATHEMATICS",
  "ENGLISH",
  "COMBINED SCIENCE",
  "ACCOUNTS",
  "GEOGRAPHY",
  "SOCIOLOGY",
  "AGRICULTURE",
  "BUSINESS STUDIES",
  "COMPUTERS",
  "HISTORY",
  "FRENCH",
]

export default function ClassTeacher() {
  const { students, marks, updateTeacherComment, updateHeadComment } = useUniversalStudentStore()
  const [selectedYear, setSelectedYear] = useState("")
  const [selectedSession, setSelectedSession] = useState("")
  const [selectedClass, setSelectedClass] = useState("")
  const [searchTerm, setSearchTerm] = useState("")

  const filteredStudents = students.filter((student) => {
    const matchesClass = !selectedClass || student.form === selectedClass
    const matchesSearch = !searchTerm || student.fullName.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesClass && matchesSearch
  })

  const getStudentMarks = (studentId: string) => {
    return marks.filter(
      (mark) => mark.studentId === studentId && mark.year === selectedYear && mark.session === selectedSession,
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-purple-700 text-white p-4 rounded-t-lg">
          <h1 className="text-2xl font-bold text-center">Class Teacher</h1>
        </div>

        <Card className="bg-white rounded-t-none">
          <CardContent className="p-6 space-y-6">
            {/* Filters */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Pick Year</Label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2025">2025</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Pick Session</Label>
                <Select value={selectedSession} onValueChange={setSelectedSession}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select session" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Term 1">Term 1</SelectItem>
                    <SelectItem value="Term 2">Term 2</SelectItem>
                    <SelectItem value="Term 3">Term 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Pick Class</Label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="FORM 1 2025">FORM 1 2025</SelectItem>
                    <SelectItem value="FORM 2 2025">FORM 2 2025</SelectItem>
                    <SelectItem value="FORM 3 2025">FORM 3 2025</SelectItem>
                    <SelectItem value="FORM 4 2025">FORM 4 2025</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Students Reports */}
            <div className="space-y-6">
              {filteredStudents.map((student) => (
                <ClassTeacherReportCard
                  key={student.id}
                  student={student}
                  marks={getStudentMarks(student.id)}
                  onUpdateTeacherComment={(comment) => updateTeacherComment(student.id, comment)}
                  onUpdateHeadComment={(comment) => updateHeadComment(student.id, comment)}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function ClassTeacherReportCard({ student, marks, onUpdateTeacherComment, onUpdateHeadComment }: any) {
  const [teacherComment, setTeacherComment] = useState(student.teacherComment || "")
  const [pastorComment, setPastorComment] = useState(student.pastorComment || "")
  const [headComment, setHeadComment] = useState(student.headComment || "")

  return (
    <Card className="bg-gray-50">
      <CardContent className="p-6">
        <div className="flex items-start gap-4 mb-6">
          <div className="w-16 h-16 bg-purple-200 rounded-lg flex items-center justify-center">
            <User className="w-8 h-8 text-purple-400" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">{student.fullName}</h3>
            <p className="text-sm text-gray-600">{student.username}</p>
          </div>
        </div>

        {/* Marks Table */}
        <div className="overflow-x-auto mb-6">
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-purple-100">
                <th className="border border-gray-300 p-2 text-left">Subject</th>
                <th className="border border-gray-300 p-2 text-left">Mark</th>
                <th className="border border-gray-300 p-2 text-left">Comment</th>
              </tr>
            </thead>
            <tbody>
              {subjects.map((subject) => {
                const mark = marks.find((m: any) => m.subject === subject)
                return (
                  <tr key={subject}>
                    <td className="border border-gray-300 p-2">{subject}</td>
                    <td className="border border-gray-300 p-2">{mark ? `${mark.mark} ${mark.grade}` : "-"}</td>
                    <td className="border border-gray-300 p-2">{mark?.comment || "-"}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {/* Comments Section */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Teacher's Comment</Label>
            <Textarea
              value={teacherComment}
              onChange={(e) => setTeacherComment(e.target.value)}
              placeholder="Enter teacher's comment"
              className="min-h-[80px]"
            />
            <Button
              onClick={() => onUpdateTeacherComment(teacherComment)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Save
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Pastor's Comment</Label>
            <Textarea
              value={pastorComment}
              onChange={(e) => setPastorComment(e.target.value)}
              placeholder="Enter pastor's comment"
              className="min-h-[80px]"
            />
            <Button className="bg-purple-600 hover:bg-purple-700">Save</Button>
          </div>

          <div className="space-y-2">
            <Label>Head's Comment</Label>
            <Textarea
              value={headComment}
              onChange={(e) => setHeadComment(e.target.value)}
              placeholder="Enter head's comment"
              className="min-h-[80px]"
            />
            <Button onClick={() => onUpdateHeadComment(headComment)} className="bg-purple-600 hover:bg-purple-700">
              Save
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
