"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { User, Printer, LogOut } from "lucide-react"
import { useUniversalStudentStore } from "../store/universal-student-store"

const subjects = [
  "MATHEMATICS",
  "ENGLISH",
  "COMBINED SCIENCE",
  "ACCOUNTS",
  "GEOGRAPHY",
  "SOCIOLOGY",
  "AGRICULTURE",
  "BUSINESS STUDIES",
  "COMPUTER SCIENCE",
  "HISTORY",
  "FRENCH",
]

interface StudentReportsProps {
  student: any
  onLogout: () => void
}

export default function StudentReports({ student, onLogout }: StudentReportsProps) {
  const { marks } = useUniversalStudentStore()
  const [selectedYear, setSelectedYear] = useState("")
  const [selectedSession, setSelectedSession] = useState("")

  useEffect(() => {
    // Set default to current year
    setSelectedYear("2025")
    setSelectedSession("First Term")
  }, [])

  const getStudentMarks = () => {
    if (!selectedYear || !selectedSession) return []

    return marks.filter(
      (mark) => mark.studentId === student.id && mark.year === selectedYear && mark.session === selectedSession,
    )
  }

  const studentMarks = getStudentMarks()
  const hasMarks = studentMarks.length > 0

  const calculateGPA = () => {
    if (studentMarks.length === 0) return "N/A"

    const gradePoints = {
      "A*": 4.0,
      A: 3.7,
      B: 3.0,
      C: 2.0,
      D: 1.0,
      E: 0.5,
      U: 0.0,
    }

    const totalPoints = studentMarks.reduce((sum, mark) => {
      return sum + (gradePoints[mark.grade as keyof typeof gradePoints] || 0)
    }, 0)

    return (totalPoints / studentMarks.length).toFixed(2)
  }

  const getAverageScore = () => {
    if (studentMarks.length === 0) return "N/A"

    const totalMarks = studentMarks.reduce((sum, mark) => sum + mark.mark, 0)
    return Math.round(totalMarks / studentMarks.length)
  }

  const handlePrint = () => {
    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    const printContent = `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Academic Report - ${student.fullName}</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            font-size: 12px;
            line-height: 1.4;
          }
          .header { 
            text-align: center; 
            margin-bottom: 20px; 
            display: flex; 
            align-items: center; 
            justify-content: space-between;
            border-bottom: 2px solid #1e3a8a;
            padding-bottom: 15px;
          }
          .logo-container {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .logo { 
            width: 60px; 
            height: 60px; 
            object-fit: contain;
            max-width: 100%;
            max-height: 100%;
          }
          .school-info { 
            text-align: center; 
            flex: 1;
          }
          .school-name { 
            font-size: 20px; 
            font-weight: bold; 
            color: #1e3a8a; 
            margin: 0; 
          }
          .school-details { 
            font-size: 10px; 
            color: #333; 
            margin: 1px 0;
          }
          .contact-info {
            font-size: 10px;
            color: #333;
            margin: 1px 0;
          }
          .email-link {
            color: #0066cc;
            text-decoration: none;
          }
          .student-info { 
            margin: 15px 0; 
            font-weight: bold;
          }
          .student-info h3 {
            margin: 5px 0;
            font-size: 14px;
          }
          .student-info p {
            margin: 2px 0;
            font-size: 12px;
          }
          .summary-stats {
            display: flex;
            justify-content: space-around;
            margin: 15px 0;
            padding: 10px;
            background-color: #f0f0f0;
            border-radius: 5px;
          }
          .stat-item {
            text-align: center;
          }
          .stat-value {
            font-size: 18px;
            font-weight: bold;
            color: #1e3a8a;
          }
          .stat-label {
            font-size: 10px;
            color: #666;
          }
          table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 15px; 
            font-size: 11px;
          }
          th, td { 
            border: 1px solid #333; 
            padding: 4px; 
            text-align: left; 
            vertical-align: top;
          }
          th { 
            background-color: #1e3a8a; 
            color: white; 
            font-weight: bold;
            text-align: center;
          }
          .subject-col { width: 30%; }
          .mark-col { width: 15%; text-align: center; }
          .grade-col { width: 15%; text-align: center; }
          .comment-col { width: 40%; }
          .comments { 
            margin-top: 15px; 
          }
          .comment-section { 
            margin-bottom: 10px; 
            border: 1px solid #ddd;
            padding: 8px;
            min-height: 40px;
          }
          .comment-label {
            font-weight: bold;
            margin-bottom: 5px;
          }
          .footer-motto { 
            text-align: center; 
            margin-top: 20px; 
            font-style: italic; 
            color: #1e3a8a; 
            font-weight: bold; 
            border-top: 1px solid #ddd;
            padding-top: 10px;
          }
          .stamp-section {
            text-align: right;
            margin-top: 15px;
            font-size: 10px;
          }
          @media print { 
            body { margin: 0; } 
            .header { page-break-inside: avoid; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo-container">
            <img src="/images/school-logo.png" alt="School Logo" class="logo" onerror="this.style.display='none'" />
          </div>
          <div class="school-info">
            <h1 class="school-name">ELIM CHRISTAIN COLLEGE</h1>
            <div class="contact-info">📞 +263772697959</div>
            <div class="contact-info">📞 +263772708299</div>
            <div class="contact-info">☎️ +0672142061</div>
            <div class="school-details">232 Station Road Banket</div>
            <div class="contact-info"><a href="mailto:elimcollege@gmail.com" class="email-link">elimcollege@gmail.com</a></div>
          </div>
          <div class="logo-container">
            <img src="/images/school-logo.png" alt="School Logo" class="logo" onerror="this.style.display='none'" />
          </div>
        </div>
        
        <div class="student-info">
          <h3>${student.fullName.toUpperCase()}</h3>
          <p>Student ID: ${student.username}</p>
          <p>Class: ${student.form}</p>
          <p>${selectedSession.toUpperCase()} ${selectedYear}</p>
        </div>

        <div class="summary-stats">
          <div class="stat-item">
            <div class="stat-value">${getAverageScore()}%</div>
            <div class="stat-label">Average Score</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">${calculateGPA()}</div>
            <div class="stat-label">GPA</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">${studentMarks.length}</div>
            <div class="stat-label">Subjects</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th class="subject-col">Subject</th>
              <th class="mark-col">Mark (%)</th>
              <th class="grade-col">Grade</th>
              <th class="comment-col">Teacher's Comment</th>
            </tr>
          </thead>
          <tbody>
            ${subjects
              .map((subject) => {
                const mark = studentMarks.find((m) => m.subject === subject)
                return `
              <tr>
                <td class="subject-col">${subject}</td>
                <td class="mark-col">${mark ? mark.mark : "-"}</td>
                <td class="grade-col">${mark ? mark.grade : "-"}</td>
                <td class="comment-col">${mark ? mark.comment || "-" : "-"}</td>
              </tr>
            `
              })
              .join("")}
          </tbody>
        </table>

        <div class="comments">
          <div class="comment-section">
            <div class="comment-label">Class Teacher's Comment</div>
            <div>${student.teacherComment || "No comment available"}</div>
          </div>
          
          <div class="comment-section">
            <div class="comment-label">Head Teacher's Comment</div>
            <div>${student.headComment || "No comment available"}</div>
          </div>
        </div>

        <div class="stamp-section">
          <p>School Stamp</p>
        </div>

        <div class="footer-motto">
          GADZIRIRO RERAMANGWANA
        </div>
      </body>
    </html>
  `

    printWindow.document.write(printContent)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-purple-700 text-white p-4 rounded-t-lg flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src="/images/school-logo.png" alt="ELIM CHRISTAIN COLLEGE Logo" className="w-10 h-10 object-contain" />
            <div>
              <h1 className="text-xl font-bold">My Academic Report</h1>
              <p className="text-purple-200 text-sm">Welcome, {student.fullName}</p>
            </div>
          </div>
          <Button variant="ghost" onClick={onLogout} className="text-white hover:bg-white/10">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>

        <Card className="bg-white rounded-t-none">
          <CardContent className="p-6 space-y-6">
            {/* Student Info */}
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-purple-200 rounded-lg flex items-center justify-center">
                  <User className="w-8 h-8 text-purple-400" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">{student.fullName}</h2>
                  <p className="text-gray-600">Student ID: {student.username}</p>
                  <p className="text-gray-600">Class: {student.form}</p>
                </div>
              </div>
            </div>

            {/* Session Selector */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Academic Year</Label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2025">2025</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Term</Label>
                <Select value={selectedSession} onValueChange={setSelectedSession}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select term" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="First Term">First Term</SelectItem>
                    <SelectItem value="Second Term">Second Term</SelectItem>
                    <SelectItem value="Third Term">Third Term</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Performance Summary */}
            {hasMarks && (
              <div className="grid md:grid-cols-3 gap-4">
                <Card className="bg-green-50">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">{getAverageScore()}%</div>
                    <div className="text-sm text-gray-600">Average Score</div>
                  </CardContent>
                </Card>
                <Card className="bg-blue-50">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">{calculateGPA()}</div>
                    <div className="text-sm text-gray-600">GPA</div>
                  </CardContent>
                </Card>
                <Card className="bg-purple-50">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-purple-600">{studentMarks.length}</div>
                    <div className="text-sm text-gray-600">Subjects Completed</div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* No Marks Message */}
            {!hasMarks && selectedYear && selectedSession && (
              <div className="bg-yellow-50 border border-yellow-200 rounded p-4">
                <p className="text-yellow-800 text-center">
                  No marks available for {selectedSession} {selectedYear}. Please contact your class teacher if you
                  believe this is an error.
                </p>
              </div>
            )}

            {/* Marks Table */}
            {hasMarks && (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-purple-100">
                      <th className="border border-gray-300 p-3 text-left">Subject</th>
                      <th className="border border-gray-300 p-3 text-center">Mark (%)</th>
                      <th className="border border-gray-300 p-3 text-center">Grade</th>
                      <th className="border border-gray-300 p-3 text-left">Teacher's Comment</th>
                    </tr>
                  </thead>
                  <tbody>
                    {subjects.map((subject) => {
                      const mark = studentMarks.find((m) => m.subject === subject)
                      return (
                        <tr key={subject} className={mark ? "bg-green-50" : "bg-gray-50"}>
                          <td className="border border-gray-300 p-3 font-medium">{subject}</td>
                          <td className="border border-gray-300 p-3 text-center">
                            {mark ? (
                              <span className="font-semibold text-blue-600">{mark.mark}%</span>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </td>
                          <td className="border border-gray-300 p-3 text-center">
                            {mark ? (
                              <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm font-medium">
                                {mark.grade}
                              </span>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </td>
                          <td className="border border-gray-300 p-3">
                            {mark?.comment ? (
                              <span className="text-sm">{mark.comment}</span>
                            ) : (
                              <span className="text-gray-400">No comment</span>
                            )}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Teacher Comments */}
            {hasMarks && (
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">Class Teacher's Comment</h3>
                  <p className="text-gray-700">{student.teacherComment || "No comment available"}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">Head Teacher's Comment</h3>
                  <p className="text-gray-700">{student.headComment || "No comment available"}</p>
                </div>
              </div>
            )}

            {/* Print Button */}
            {hasMarks && (
              <div className="text-center">
                <Button
                  onClick={handlePrint}
                  className="bg-green-600 hover:bg-green-700 flex items-center gap-2 mx-auto"
                >
                  <Printer className="w-4 h-4" />
                  Print My Report
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
