"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Save, Users } from "lucide-react"
import { useUniversalStudentStore } from "../store/universal-student-store"

const subjects = [
  "Mathematics",
  "English Language",
  "Science",
  "Social Studies",
  "French",
  "Spanish",
  "Physical Education",
  "Art",
  "Music",
  "Computer Studies",
  "Religious Education",
  "Geography",
  "History",
  "Biology",
  "Chemistry",
  "Physics",
  "Literature",
  "Economics",
  "Business Studies",
]

const sessions = ["First Term", "Second Term", "Third Term"]
const currentYear = new Date().getFullYear().toString()

function getGrade(mark: number): string {
  if (mark >= 90) return "A+"
  if (mark >= 80) return "A"
  if (mark >= 70) return "B+"
  if (mark >= 60) return "B"
  if (mark >= 50) return "C+"
  if (mark >= 40) return "C"
  if (mark >= 30) return "D"
  return "F"
}

export default function EnterMarks() {
  const { students, marks, addMark, updateMark } = useUniversalStudentStore()

  const [selectedStudent, setSelectedStudent] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")
  const [selectedSession, setSelectedSession] = useState("First Term")
  const [selectedYear, setSelectedYear] = useState(currentYear)
  const [markValue, setMarkValue] = useState("")
  const [comment, setComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Initialize store on component mount
  useEffect(() => {
    // Store should already be initialized, but this ensures it
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedStudent || !selectedSubject || !markValue) {
      alert("Please fill in all required fields")
      return
    }

    const mark = Number.parseInt(markValue)
    if (isNaN(mark) || mark < 0 || mark > 100) {
      alert("Please enter a valid mark between 0 and 100")
      return
    }

    setIsSubmitting(true)

    try {
      const grade = getGrade(mark)

      // Check if mark already exists
      const existingMark = marks.find(
        (m) =>
          m.studentId === selectedStudent &&
          m.subject === selectedSubject &&
          m.session === selectedSession &&
          m.year === selectedYear,
      )

      if (existingMark) {
        // Update existing mark
        await updateMark(existingMark.id, {
          mark,
          grade,
          comment,
        })
        alert("Mark updated successfully!")
      } else {
        // Add new mark
        await addMark({
          studentId: selectedStudent,
          year: selectedYear,
          session: selectedSession,
          subject: selectedSubject,
          mark,
          grade,
          comment,
        })
        alert("Mark added successfully!")
      }

      // Reset form
      setMarkValue("")
      setComment("")
    } catch (error) {
      console.error("Error saving mark:", error)
      alert("Failed to save mark. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Get existing mark for selected student/subject/session/year
  const existingMark = marks.find(
    (m) =>
      m.studentId === selectedStudent &&
      m.subject === selectedSubject &&
      m.session === selectedSession &&
      m.year === selectedYear,
  )

  // Update form when existing mark is found
  useEffect(() => {
    if (existingMark) {
      setMarkValue(existingMark.mark.toString())
      setComment(existingMark.comment || "")
    } else {
      setMarkValue("")
      setComment("")
    }
  }, [existingMark])

  const selectedStudentData = students.find((s) => s.id === selectedStudent)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Enter Student Marks
          </CardTitle>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{students.length} Students</span>
            </div>
            <div className="flex items-center gap-1">
              <BookOpen className="h-4 w-4" />
              <span>{marks.length} Marks</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {students.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No students found. Please add students first.</p>
              <p className="text-sm text-gray-500 mt-2">🔥 Students will sync from Firebase automatically</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Academic Period */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="year">Academic Year *</Label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={currentYear}>{currentYear}</SelectItem>
                      <SelectItem value={(Number.parseInt(currentYear) - 1).toString()}>
                        {Number.parseInt(currentYear) - 1}
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="session">Session/Term *</Label>
                  <Select value={selectedSession} onValueChange={setSelectedSession}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select session" />
                    </SelectTrigger>
                    <SelectContent>
                      {sessions.map((session) => (
                        <SelectItem key={session} value={session}>
                          {session}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Student and Academic Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="student">Select Student *</Label>
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a student" />
                    </SelectTrigger>
                    <SelectContent>
                      {students.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.fullName} ({student.form})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedStudentData && (
                    <div className="mt-2 p-3 bg-blue-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <img
                          src={selectedStudentData.profileImage || "/placeholder.svg"}
                          alt={selectedStudentData.fullName}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div>
                          <div className="font-medium">{selectedStudentData.fullName}</div>
                          <div className="text-sm text-gray-600">{selectedStudentData.form}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="subject">Subject *</Label>
                  <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject} value={subject}>
                          {subject}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Mark Entry */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="mark">Mark (0-100) *</Label>
                  <Input
                    id="mark"
                    type="number"
                    min="0"
                    max="100"
                    value={markValue}
                    onChange={(e) => setMarkValue(e.target.value)}
                    placeholder="Enter mark"
                    required
                  />
                  {markValue && (
                    <p className="text-sm text-gray-600 mt-1">
                      Grade: <span className="font-semibold">{getGrade(Number.parseInt(markValue))}</span>
                    </p>
                  )}
                </div>

                <div>
                  <Label>Grade</Label>
                  <div className="flex items-center h-10">
                    {markValue && !isNaN(Number.parseInt(markValue)) ? (
                      <Badge variant="secondary" className="text-lg">
                        {getGrade(Number.parseInt(markValue))}
                      </Badge>
                    ) : (
                      <span className="text-gray-400">Enter mark to see grade</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Comment */}
              <div>
                <Label htmlFor="comment">Comment (Optional)</Label>
                <Input
                  id="comment"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Add a comment about this mark"
                />
              </div>

              {/* Existing Mark Warning */}
              {existingMark && (
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                  <p className="text-sm text-yellow-800">
                    <strong>Existing Mark Found:</strong> {existingMark.mark} ({existingMark.grade}) - This will be
                    updated with the new mark.
                  </p>
                </div>
              )}

              {/* Submit Button */}
              <div className="flex items-center gap-4 pt-4">
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  <Save className="w-4 h-4 mr-2" />
                  {isSubmitting ? "Saving..." : existingMark ? "Update Mark" : "Save Mark"}
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>

      {/* Recent Marks */}
      {marks.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Marks ({marks.length} total)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {marks.slice(0, 10).map((mark) => {
                const student = students.find((s) => s.id === mark.studentId)
                return (
                  <div key={mark.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <div>
                      <span className="font-medium">{student?.fullName || "Unknown Student"}</span>
                      <span className="text-sm text-gray-600 ml-2">
                        {mark.subject} - {mark.year} {mark.session}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-lg">{mark.mark}</span>
                      <span className="text-sm text-gray-600 ml-1">({mark.grade})</span>
                    </div>
                  </div>
                )
              })}
            </div>
            <p className="text-xs text-gray-500 mt-2">🔥 All marks sync instantly to Firebase</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
