"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SettingsIcon, Key, Users, Shield, Database } from "lucide-react"
import { useAuthStore } from "../store/auth-store"
import DataSync from "./data-sync"

interface SettingsProps {
  userRole: string
}

export default function Settings({ userRole }: SettingsProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-purple-700 text-white p-4 rounded-t-lg">
          <h1 className="text-2xl font-bold text-center flex items-center justify-center gap-2">
            <SettingsIcon className="w-6 h-6" />
            Settings
          </h1>
        </div>

        <Card className="bg-white rounded-t-none">
          <CardContent className="p-6">
            <Tabs defaultValue="password" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="password" className="flex items-center gap-2">
                  <Key className="w-4 h-4" />
                  Change Password
                </TabsTrigger>
                {userRole === "admin" && (
                  <TabsTrigger value="users" className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Manage Users
                  </TabsTrigger>
                )}
                <TabsTrigger value="sync" className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  Data Sync
                </TabsTrigger>
              </TabsList>

              <TabsContent value="password" className="space-y-4">
                <ChangePasswordForm userRole={userRole} />
              </TabsContent>

              {userRole === "admin" && (
                <TabsContent value="users" className="space-y-4">
                  <ManageUsersForm />
                </TabsContent>
              )}

              <TabsContent value="sync" className="space-y-4">
                <DataSync />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function ChangePasswordForm({ userRole }: { userRole: string }) {
  const { updatePassword } = useAuthStore()
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  const handleChangePassword = () => {
    setMessage("")
    setError("")

    if (!currentPassword || !newPassword || !confirmPassword) {
      setError("Please fill in all fields")
      return
    }

    if (newPassword !== confirmPassword) {
      setError("New passwords do not match")
      return
    }

    if (newPassword.length < 6) {
      setError("New password must be at least 6 characters long")
      return
    }

    const success = updatePassword(userRole, currentPassword, newPassword)

    if (success) {
      setMessage("Password changed successfully!")
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
    } else {
      setError("Current password is incorrect")
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5" />
          Change Your Password
        </CardTitle>
        <CardDescription>Update your login password. Make sure to use a strong password.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {message && (
          <Alert className="bg-green-50 border-green-200">
            <AlertDescription className="text-green-800">{message}</AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert className="bg-red-50 border-red-200">
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-2">
          <Label htmlFor="currentPassword">Current Password</Label>
          <Input
            id="currentPassword"
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            placeholder="Enter current password"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="newPassword">New Password</Label>
          <Input
            id="newPassword"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="Enter new password"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="confirmPassword">Confirm New Password</Label>
          <Input
            id="confirmPassword"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm new password"
          />
        </div>

        <Button onClick={handleChangePassword} className="w-full bg-purple-600 hover:bg-purple-700">
          Change Password
        </Button>
      </CardContent>
    </Card>
  )
}

function ManageUsersForm() {
  const { users, addUser, updateUserPassword, deleteUser } = useAuthStore()
  const [newUsername, setNewUsername] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [newRole, setNewRole] = useState("teacher")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  const handleAddUser = () => {
    setMessage("")
    setError("")

    if (!newUsername || !newPassword) {
      setError("Please fill in all fields")
      return
    }

    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters long")
      return
    }

    const success = addUser(newUsername, newPassword, newRole as "teacher" | "admin")

    if (success) {
      setMessage(`User ${newUsername} added successfully!`)
      setNewUsername("")
      setNewPassword("")
      setNewRole("teacher")
    } else {
      setError("Username already exists")
    }
  }

  const handleResetPassword = (username: string) => {
    const newPass = prompt(`Enter new password for ${username}:`)
    if (newPass && newPass.length >= 6) {
      updateUserPassword(username, newPass)
      setMessage(`Password reset for ${username}`)
    } else if (newPass) {
      setError("Password must be at least 6 characters long")
    }
  }

  const handleDeleteUser = (username: string) => {
    if (username === "admin") {
      setError("Cannot delete the main admin account")
      return
    }

    if (confirm(`Are you sure you want to delete user ${username}?`)) {
      deleteUser(username)
      setMessage(`User ${username} deleted successfully`)
    }
  }

  return (
    <div className="space-y-6">
      {/* Add New User */}
      <Card>
        <CardHeader>
          <CardTitle>Add New User</CardTitle>
          <CardDescription>Create new teacher or admin accounts</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {message && (
            <Alert className="bg-green-50 border-green-200">
              <AlertDescription className="text-green-800">{message}</AlertDescription>
            </Alert>
          )}

          {error && (
            <Alert className="bg-red-50 border-red-200">
              <AlertDescription className="text-red-800">{error}</AlertDescription>
            </Alert>
          )}

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="newUsername">Username</Label>
              <Input
                id="newUsername"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="Enter username"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="newPassword">Password</Label>
              <Input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="newRole">Role</Label>
              <select
                id="newRole"
                value={newRole}
                onChange={(e) => setNewRole(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md"
              >
                <option value="teacher">Teacher</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </div>

          <Button onClick={handleAddUser} className="bg-purple-600 hover:bg-purple-700">
            Add User
          </Button>
        </CardContent>
      </Card>

      {/* Existing Users */}
      <Card>
        <CardHeader>
          <CardTitle>Existing Users</CardTitle>
          <CardDescription>Manage existing teacher and admin accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((user) => (
              <div key={user.username} className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-semibold">{user.username}</h4>
                  <p className="text-sm text-gray-600 capitalize">{user.role}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleResetPassword(user.username)}>
                    Reset Password
                  </Button>
                  {user.username !== "admin" && (
                    <Button variant="destructive" size="sm" onClick={() => handleDeleteUser(user.username)}>
                      Delete
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
