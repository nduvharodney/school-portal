"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Download, Upload, Share2, Copy, Check, RefreshCw, Database } from "lucide-react"
import { useUniversalStudentStore } from "../store/universal-student-store"
import { useAuthStore } from "../store/auth-store"

export default function DataSync() {
  const { students, marks } = useUniversalStudentStore()
  const { users } = useAuthStore()
  const [importData, setImportData] = useState("")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")
  const [shareUrl, setShareUrl] = useState("")
  const [copied, setCopied] = useState(false)

  const exportData = () => {
    const data = {
      students,
      marks,
      users,
      exportDate: new Date().toISOString(),
      version: "1.0",
    }

    const dataStr = JSON.stringify(data, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)

    const link = document.createElement("a")
    link.href = url
    link.download = `elim-college-data-${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    setMessage("Data exported successfully! Share this file with other devices.")
  }

  const importDataFromFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string)
        importDataFromJson(data)
      } catch (err) {
        setError("Invalid file format. Please select a valid backup file.")
      }
    }
    reader.readAsText(file)
  }

  const importDataFromJson = (data: any) => {
    try {
      if (!data.students || !data.marks || !data.users) {
        throw new Error("Invalid data format")
      }

      // Import to stores
      useUniversalStudentStore.setState({
        students: data.students,
        marks: data.marks,
      })

      useAuthStore.setState({
        users: data.users,
      })

      setMessage(`Data imported successfully! 
      - ${data.students.length} students
      - ${data.marks.length} marks
      - ${data.users.length} users
      - Export date: ${new Date(data.exportDate).toLocaleString()}`)
      setError("")
      setImportData("")
    } catch (err) {
      setError("Failed to import data. Please check the format and try again.")
    }
  }

  const handleTextImport = () => {
    if (!importData.trim()) {
      setError("Please paste the data to import")
      return
    }

    try {
      const data = JSON.parse(importData)
      importDataFromJson(data)
    } catch (err) {
      setError("Invalid JSON format. Please check the data and try again.")
    }
  }

  const generateShareableData = () => {
    const data = {
      students,
      marks,
      users,
      exportDate: new Date().toISOString(),
      version: "1.0",
    }

    const encodedData = btoa(JSON.stringify(data))
    const baseUrl = window.location.origin + window.location.pathname
    const url = `${baseUrl}?data=${encodedData}`

    setShareUrl(url)
    setMessage("Shareable link generated! Copy and open on other devices.")
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement("textarea")
      textArea.value = shareUrl
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand("copy")
      document.body.removeChild(textArea)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getCurrentStats = () => {
    return {
      students: students.length,
      marks: marks.length,
      users: users.length,
      lastUpdated: localStorage.getItem("student-store")
        ? new Date(
            JSON.parse(localStorage.getItem("student-store") || "{}").state?.students?.[0]?.createdAt || Date.now(),
          ).toLocaleString()
        : "Never",
    }
  }

  const stats = getCurrentStats()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-purple-700 text-white p-4 rounded-t-lg">
          <h1 className="text-2xl font-bold text-center flex items-center justify-center gap-2">
            <Database className="w-6 h-6" />
            Data Synchronization
          </h1>
        </div>

        <Card className="bg-white rounded-t-none">
          <CardContent className="p-6 space-y-6">
            {/* Current Data Stats */}
            <Card className="bg-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RefreshCw className="w-5 h-5" />
                  Current Data Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">{stats.students}</div>
                    <div className="text-sm text-gray-600">Students</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-600">{stats.marks}</div>
                    <div className="text-sm text-gray-600">Marks</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-purple-600">{stats.users}</div>
                    <div className="text-sm text-gray-600">Users</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-gray-600">Last Updated</div>
                    <div className="text-xs text-gray-500">{stats.lastUpdated}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {message && (
              <Alert className="bg-green-50 border-green-200">
                <AlertDescription className="text-green-800">{message}</AlertDescription>
              </Alert>
            )}

            {error && (
              <Alert className="bg-red-50 border-red-200">
                <AlertDescription className="text-red-800">{error}</AlertDescription>
              </Alert>
            )}

            {/* Export Data */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="w-5 h-5" />
                  Export Data
                </CardTitle>
                <CardDescription>Download all school data to share with other devices</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={exportData} className="w-full bg-blue-600 hover:bg-blue-700">
                  <Download className="w-4 h-4 mr-2" />
                  Download Backup File
                </Button>

                <div className="text-center text-gray-500 text-sm">OR</div>

                <Button onClick={generateShareableData} className="w-full bg-purple-600 hover:bg-purple-700">
                  <Share2 className="w-4 h-4 mr-2" />
                  Generate Shareable Link
                </Button>

                {shareUrl && (
                  <div className="space-y-2">
                    <Label>Shareable Link (Copy and open on other devices)</Label>
                    <div className="flex gap-2">
                      <Input value={shareUrl} readOnly className="text-xs" />
                      <Button
                        onClick={copyToClipboard}
                        variant="outline"
                        className="flex items-center gap-1 bg-transparent"
                      >
                        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        {copied ? "Copied!" : "Copy"}
                      </Button>
                    </div>
                    <p className="text-xs text-gray-600">
                      Open this link on any device to automatically import the data
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Import Data */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5" />
                  Import Data
                </CardTitle>
                <CardDescription>Import data from another device or backup file</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Import from File</Label>
                  <Input type="file" accept=".json" onChange={importDataFromFile} className="cursor-pointer" />
                </div>

                <div className="text-center text-gray-500 text-sm">OR</div>

                <div className="space-y-2">
                  <Label>Paste Data</Label>
                  <Textarea
                    value={importData}
                    onChange={(e) => setImportData(e.target.value)}
                    placeholder="Paste the exported data here..."
                    className="min-h-[100px] font-mono text-xs"
                  />
                  <Button
                    onClick={handleTextImport}
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={!importData.trim()}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Import Data
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Instructions */}
            <Card className="bg-yellow-50">
              <CardHeader>
                <CardTitle className="text-yellow-800">How to Sync Data Between Devices</CardTitle>
              </CardHeader>
              <CardContent className="text-yellow-700 space-y-2">
                <p>
                  <strong>Method 1 - File Transfer:</strong>
                </p>
                <ol className="list-decimal list-inside space-y-1 ml-4">
                  <li>Click "Download Backup File" on the main device</li>
                  <li>Transfer the downloaded file to your phone (email, WhatsApp, etc.)</li>
                  <li>On your phone, go to Data Sync and select "Import from File"</li>
                  <li>Choose the downloaded file</li>
                </ol>

                <p className="mt-4">
                  <strong>Method 2 - Shareable Link:</strong>
                </p>
                <ol className="list-decimal list-inside space-y-1 ml-4">
                  <li>Click "Generate Shareable Link" on the main device</li>
                  <li>Copy the generated link</li>
                  <li>Open the link on your phone's browser</li>
                  <li>The data will automatically import</li>
                </ol>

                <p className="mt-4 text-sm">
                  <strong>Note:</strong> Always export data after adding new students or marks to keep all devices
                  synchronized.
                </p>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
