"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

interface Student {
  id: string
  firstName: string
  lastName: string
  fullName: string
  username: string
  password: string
  dateOfBirth: string
  gender: string
  contactNumber: string
  address: string
  form: string
  guardianFirstName: string
  guardianLastName: string
  relationship: string
  guardianIdNo: string
  guardianContact: string
  guardianAddress: string
  profileImage: string
  teacherComment?: string
  headComment?: string
  pastorComment?: string
  createdAt: string
}

interface Mark {
  id: string
  studentId: string
  year: string
  session: string
  subject: string
  mark: number
  grade: string
  comment: string
  createdAt: string
}

interface StudentStore {
  students: Student[]
  marks: Mark[]
  addStudent: (student: Student) => void
  addMark: (studentId: string, mark: Omit<Mark, "id" | "studentId">) => void
  updateMark: (markId: string, updates: Partial<Mark>) => void
  deleteMark: (markId: string) => void
  updateTeacherComment: (studentId: string, comment: string) => void
  updateHeadComment: (studentId: string, comment: string) => void
  updatePastorComment: (studentId: string, comment: string) => void
  deleteStudent: (studentId: string) => void
}

export const useStudentStore = create<StudentStore>()(
  persist(
    (set, get) => ({
      students: [],
      marks: [],

      addStudent: (student) => {
        set((state) => ({
          students: [...state.students, student],
        }))
      },

      addMark: (studentId, markData) => {
        const newMark: Mark = {
          id: Date.now().toString(),
          studentId,
          ...markData,
        }

        console.log("=== ADDING NEW MARK ===")
        console.log("New mark object:", newMark)

        set((state) => {
          // Remove existing mark for same student, year, session, subject
          const filteredMarks = state.marks.filter(
            (mark) =>
              !(
                mark.studentId === studentId &&
                mark.year === markData.year &&
                mark.session === markData.session &&
                mark.subject === markData.subject
              ),
          )

          const updatedMarks = [...filteredMarks, newMark]
          console.log("Updated marks array:", updatedMarks)

          return {
            marks: updatedMarks,
          }
        })
      },

      updateMark: (markId, updates) => {
        console.log("=== UPDATING MARK ===")
        console.log("Mark ID:", markId)
        console.log("Updates:", updates)

        set((state) => ({
          marks: state.marks.map((mark) => (mark.id === markId ? { ...mark, ...updates } : mark)),
        }))
      },

      deleteMark: (markId) => {
        console.log("=== DELETING MARK ===")
        console.log("Mark ID:", markId)

        set((state) => ({
          marks: state.marks.filter((mark) => mark.id !== markId),
        }))
      },

      updateTeacherComment: (studentId, comment) => {
        set((state) => ({
          students: state.students.map((student) =>
            student.id === studentId ? { ...student, teacherComment: comment } : student,
          ),
        }))
      },

      updateHeadComment: (studentId, comment) => {
        set((state) => ({
          students: state.students.map((student) =>
            student.id === studentId ? { ...student, headComment: comment } : student,
          ),
        }))
      },

      updatePastorComment: (studentId, comment) => {
        set((state) => ({
          students: state.students.map((student) =>
            student.id === studentId ? { ...student, pastorComment: comment } : student,
          ),
        }))
      },

      deleteStudent: (studentId) => {
        set((state) => ({
          students: state.students.filter((student) => student.id !== studentId),
          marks: state.marks.filter((mark) => mark.studentId !== studentId),
        }))
      },
    }),
    {
      name: "student-store",
    },
  ),
)
