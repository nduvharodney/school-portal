"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import { syncManager } from "../lib/local-sync"

interface Student {
  id: string
  firstName: string
  lastName: string
  fullName: string
  username: string
  password: string
  dateOfBirth: string
  gender: string
  contactNumber: string
  address: string
  form: string
  guardianFirstName: string
  guardianLastName: string
  relationship: string
  guardianIdNo: string
  guardianContact: string
  guardianAddress: string
  profileImage: string
  teacherComment?: string
  headComment?: string
  pastorComment?: string
  createdAt: string
}

interface Mark {
  id: string
  studentId: string
  year: string
  session: string
  subject: string
  mark: number
  grade: string
  comment: string
  createdAt: string
}

interface RealtimeStudentStore {
  students: Student[]
  marks: Mark[]
  isOnline: boolean
  isSyncing: boolean
  lastSyncTime: string
  syncStatus: "connected" | "syncing" | "offline" | "error"

  // Student operations
  addStudent: (student: Omit<Student, "id">) => Promise<void>
  updateStudent: (studentId: string, updates: Partial<Student>) => Promise<void>
  deleteStudent: (studentId: string) => Promise<void>

  // Mark operations
  addMark: (studentId: string, mark: Omit<Mark, "id" | "studentId">) => Promise<void>
  updateMark: (markId: string, updates: Partial<Mark>) => Promise<void>
  deleteMark: (markId: string) => Promise<void>

  // Comment operations
  updateTeacherComment: (studentId: string, comment: string) => Promise<void>
  updateHeadComment: (studentId: string, comment: string) => Promise<void>
  updatePastorComment: (studentId: string, comment: string) => Promise<void>

  // Sync operations
  initializeSync: () => void
  forceSync: () => Promise<void>
  setOnlineStatus: (status: boolean) => void
}

export const useRealtimeStudentStore = create<RealtimeStudentStore>()(
  persist(
    (set, get) => ({
      students: [],
      marks: [],
      isOnline: typeof window !== "undefined" ? navigator.onLine : false,
      isSyncing: false,
      lastSyncTime: "",
      syncStatus: "connected",

      // Initialize real-time sync
      initializeSync: () => {
        console.log("🔄 Initializing real-time local sync...")

        // Subscribe to student changes
        syncManager.subscribe("students", (students: Student[]) => {
          console.log(`📚 Received ${students.length} students from sync`)
          set({
            students,
            lastSyncTime: new Date().toLocaleString(),
            isSyncing: false,
            syncStatus: "connected",
          })
        })

        // Subscribe to mark changes
        syncManager.subscribe("marks", (marks: Mark[]) => {
          console.log(`📊 Received ${marks.length} marks from sync`)
          set({
            marks,
            lastSyncTime: new Date().toLocaleString(),
            isSyncing: false,
            syncStatus: "connected",
          })
        })

        // Load initial data from localStorage
        const storedStudents = syncManager.getData("students")
        const storedMarks = syncManager.getData("marks")

        if (storedStudents) {
          set({ students: storedStudents })
        }
        if (storedMarks) {
          set({ marks: storedMarks })
        }

        // Monitor online status
        if (typeof window !== "undefined") {
          const handleOnline = () => {
            console.log("🌐 Device is online")
            set({ isOnline: true, syncStatus: "connected" })
          }

          const handleOffline = () => {
            console.log("📴 Device is offline")
            set({ isOnline: false, syncStatus: "offline" })
          }

          window.addEventListener("online", handleOnline)
          window.addEventListener("offline", handleOffline)
        }

        console.log("✅ Real-time sync initialized")
      },

      // Add student with real-time sync
      addStudent: async (studentData) => {
        set({ isSyncing: true, syncStatus: "syncing" })

        try {
          const student = {
            ...studentData,
            id: Date.now().toString(),
            createdAt: new Date().toISOString(),
          }

          console.log("➕ Adding student with real-time sync:", student.fullName)

          // Update local state
          const { students } = get()
          const updatedStudents = [student, ...students]

          set({ students: updatedStudents })

          // Broadcast to all devices with simulated network delay
          await syncManager.broadcastWithDelay("students", updatedStudents)

          console.log("✅ Student added and synced to all devices")

          set({
            isSyncing: false,
            syncStatus: "connected",
            lastSyncTime: new Date().toLocaleString(),
          })
        } catch (error) {
          console.error("❌ Error adding student:", error)
          set({ isSyncing: false, syncStatus: "error" })
          throw error
        }
      },

      // Update student with real-time sync
      updateStudent: async (studentId, updates) => {
        set({ isSyncing: true, syncStatus: "syncing" })

        try {
          console.log("📝 Updating student with real-time sync:", studentId)

          const { students } = get()
          const updatedStudents = students.map((student) =>
            student.id === studentId ? { ...student, ...updates } : student,
          )

          set({ students: updatedStudents })

          // Broadcast to all devices
          await syncManager.broadcastWithDelay("students", updatedStudents)

          console.log("✅ Student updated and synced to all devices")

          set({
            isSyncing: false,
            syncStatus: "connected",
            lastSyncTime: new Date().toLocaleString(),
          })
        } catch (error) {
          console.error("❌ Error updating student:", error)
          set({ isSyncing: false, syncStatus: "error" })
          throw error
        }
      },

      // Delete student with real-time sync
      deleteStudent: async (studentId) => {
        set({ isSyncing: true, syncStatus: "syncing" })

        try {
          console.log("🗑️ Deleting student with real-time sync:", studentId)

          const { students, marks } = get()
          const updatedStudents = students.filter((student) => student.id !== studentId)
          const updatedMarks = marks.filter((mark) => mark.studentId !== studentId)

          set({ students: updatedStudents, marks: updatedMarks })

          // Broadcast both updates
          await syncManager.broadcastWithDelay("students", updatedStudents)
          await syncManager.broadcastWithDelay("marks", updatedMarks)

          console.log("✅ Student and related marks deleted and synced")

          set({
            isSyncing: false,
            syncStatus: "connected",
            lastSyncTime: new Date().toLocaleString(),
          })
        } catch (error) {
          console.error("❌ Error deleting student:", error)
          set({ isSyncing: false, syncStatus: "error" })
          throw error
        }
      },

      // Add mark with real-time sync
      addMark: async (studentId, markData) => {
        set({ isSyncing: true, syncStatus: "syncing" })

        try {
          const mark = {
            ...markData,
            id: Date.now().toString(),
            studentId,
            createdAt: new Date().toISOString(),
          }

          console.log("➕ Adding mark with real-time sync:", mark.subject, "for student", studentId)

          const { marks } = get()

          // Remove existing mark for same student/subject/term/year
          const filteredMarks = marks.filter(
            (m) =>
              !(
                m.studentId === studentId &&
                m.subject === markData.subject &&
                m.year === markData.year &&
                m.session === markData.session
              ),
          )

          const updatedMarks = [mark, ...filteredMarks]
          set({ marks: updatedMarks })

          // Broadcast to all devices
          await syncManager.broadcastWithDelay("marks", updatedMarks)

          console.log("✅ Mark added and synced to all devices")

          set({
            isSyncing: false,
            syncStatus: "connected",
            lastSyncTime: new Date().toLocaleString(),
          })
        } catch (error) {
          console.error("❌ Error adding mark:", error)
          set({ isSyncing: false, syncStatus: "error" })
          throw error
        }
      },

      // Update mark with real-time sync
      updateMark: async (markId, updates) => {
        set({ isSyncing: true, syncStatus: "syncing" })

        try {
          console.log("📝 Updating mark with real-time sync:", markId)

          const { marks } = get()
          const updatedMarks = marks.map((mark) => (mark.id === markId ? { ...mark, ...updates } : mark))

          set({ marks: updatedMarks })

          // Broadcast to all devices
          await syncManager.broadcastWithDelay("marks", updatedMarks)

          console.log("✅ Mark updated and synced to all devices")

          set({
            isSyncing: false,
            syncStatus: "connected",
            lastSyncTime: new Date().toLocaleString(),
          })
        } catch (error) {
          console.error("❌ Error updating mark:", error)
          set({ isSyncing: false, syncStatus: "error" })
          throw error
        }
      },

      // Delete mark with real-time sync
      deleteMark: async (markId) => {
        set({ isSyncing: true, syncStatus: "syncing" })

        try {
          console.log("🗑️ Deleting mark with real-time sync:", markId)

          const { marks } = get()
          const updatedMarks = marks.filter((mark) => mark.id !== markId)

          set({ marks: updatedMarks })

          // Broadcast to all devices
          await syncManager.broadcastWithDelay("marks", updatedMarks)

          console.log("✅ Mark deleted and synced to all devices")

          set({
            isSyncing: false,
            syncStatus: "connected",
            lastSyncTime: new Date().toLocaleString(),
          })
        } catch (error) {
          console.error("❌ Error deleting mark:", error)
          set({ isSyncing: false, syncStatus: "error" })
          throw error
        }
      },

      // Update teacher comment
      updateTeacherComment: async (studentId, comment) => {
        await get().updateStudent(studentId, { teacherComment: comment })
      },

      // Update head comment
      updateHeadComment: async (studentId, comment) => {
        await get().updateStudent(studentId, { headComment: comment })
      },

      // Update pastor comment
      updatePastorComment: async (studentId, comment) => {
        await get().updateStudent(studentId, { pastorComment: comment })
      },

      // Force sync
      forceSync: async () => {
        set({ isSyncing: true, syncStatus: "syncing" })

        try {
          console.log("🔄 Force syncing data...")

          // Reload data from localStorage
          const storedStudents = syncManager.getData("students")
          const storedMarks = syncManager.getData("marks")

          set({
            students: storedStudents || [],
            marks: storedMarks || [],
            lastSyncTime: new Date().toLocaleString(),
            isSyncing: false,
            syncStatus: "connected",
          })

          console.log("✅ Force sync completed")
        } catch (error) {
          console.error("❌ Error during force sync:", error)
          set({ isSyncing: false, syncStatus: "error" })
          throw error
        }
      },

      // Set online status
      setOnlineStatus: (status) => {
        set({
          isOnline: status,
          syncStatus: status ? "connected" : "offline",
        })
      },
    }),
    {
      name: "realtime-student-store",
    },
  ),
)
