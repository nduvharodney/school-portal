"use client"

import { create } from "zustand"
import { firebaseSync } from "../lib/firebase-sync"

interface Student {
  id: string
  firstName: string
  lastName: string
  fullName: string
  username: string
  password: string
  dateOfBirth: string
  gender: string
  contactNumber: string
  address: string
  form: string
  guardianFirstName: string
  guardianLastName: string
  relationship: string
  guardianIdNo: string
  guardianContact: string
  guardianAddress: string
  profileImage: string
  teacherComment?: string
  headComment?: string
  pastorComment?: string
  createdAt: string
}

interface Mark {
  id: string
  studentId: string
  year: string
  session: string
  subject: string
  mark: number
  grade: string
  comment: string
  createdAt: string
}

interface UniversalStudentStore {
  students: Student[]
  marks: Mark[]
  isLoading: boolean
  error: string | null
  syncStatus: string
  lastSyncTime: string

  // Actions
  initializeStore: () => void
  addStudent: (student: Omit<Student, "id" | "createdAt">) => Promise<void>
  updateStudent: (id: string, updates: Partial<Student>) => Promise<void>
  deleteStudent: (id: string) => Promise<void>
  addMark: (mark: Omit<Mark, "id" | "createdAt">) => Promise<void>
  updateMark: (id: string, updates: Partial<Mark>) => Promise<void>
  deleteMark: (id: string) => Promise<void>
  forceSync: () => Promise<void>
  clearError: () => void
}

export const useUniversalStudentStore = create<UniversalStudentStore>((set, get) => ({
  students: [],
  marks: [],
  isLoading: false,
  error: null,
  syncStatus: "Initializing...",
  lastSyncTime: "",

  initializeStore: () => {
    console.log("🚀 Initializing Universal Student Store...")

    set({
      isLoading: true,
      syncStatus: "Connecting...",
      error: null,
    })

    // Subscribe to students
    const unsubscribeStudents = firebaseSync.subscribe("students", (students) => {
      console.log("📚 Students updated:", students.length)
      set({
        students,
        lastSyncTime: new Date().toLocaleTimeString(),
        syncStatus: "Connected",
        isLoading: false,
        error: null,
      })
    })

    // Subscribe to marks
    const unsubscribeMarks = firebaseSync.subscribe("marks", (marks) => {
      console.log("📊 Marks updated:", marks.length)
      set({
        marks,
        lastSyncTime: new Date().toLocaleTimeString(),
        syncStatus: "Connected",
        isLoading: false,
        error: null,
      })
    })

    // Store cleanup functions
    if (typeof window !== "undefined") {
      window.addEventListener("beforeunload", () => {
        unsubscribeStudents()
        unsubscribeMarks()
      })
    }

    console.log("✅ Universal Student Store initialized")
  },

  addStudent: async (studentData) => {
    try {
      set({ syncStatus: "Adding student..." })

      const student: Student = {
        ...studentData,
        id: `student_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
        createdAt: new Date().toISOString(),
      }

      await firebaseSync.addItem("students", student)

      console.log("✅ Student added:", student.fullName)
      set({
        syncStatus: "Student added successfully",
        error: null,
      })

      // Reset status after 2 seconds
      setTimeout(() => {
        set({ syncStatus: "Connected" })
      }, 2000)
    } catch (error) {
      console.error("❌ Error adding student:", error)
      set({
        error: `Failed to add student: ${error}`,
        syncStatus: "Error",
      })
    }
  },

  updateStudent: async (id, updates) => {
    try {
      set({ syncStatus: "Updating student..." })

      await firebaseSync.updateItem("students", id, updates)

      console.log("✅ Student updated:", id)
      set({
        syncStatus: "Student updated successfully",
        error: null,
      })

      setTimeout(() => {
        set({ syncStatus: "Connected" })
      }, 2000)
    } catch (error) {
      console.error("❌ Error updating student:", error)
      set({
        error: `Failed to update student: ${error}`,
        syncStatus: "Error",
      })
    }
  },

  deleteStudent: async (id) => {
    try {
      set({ syncStatus: "Deleting student..." })

      // Delete student
      await firebaseSync.deleteItem("students", id)

      // Delete associated marks
      const { marks } = get()
      const studentMarks = marks.filter((mark) => mark.studentId === id)

      for (const mark of studentMarks) {
        await firebaseSync.deleteItem("marks", mark.id)
      }

      console.log("✅ Student and marks deleted:", id)
      set({
        syncStatus: "Student deleted successfully",
        error: null,
      })

      setTimeout(() => {
        set({ syncStatus: "Connected" })
      }, 2000)
    } catch (error) {
      console.error("❌ Error deleting student:", error)
      set({
        error: `Failed to delete student: ${error}`,
        syncStatus: "Error",
      })
    }
  },

  addMark: async (markData) => {
    try {
      set({ syncStatus: "Adding mark..." })

      const mark: Mark = {
        ...markData,
        id: `mark_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
        createdAt: new Date().toISOString(),
      }

      await firebaseSync.addItem("marks", mark)

      console.log("✅ Mark added:", mark.subject, mark.mark)
      set({
        syncStatus: "Mark added successfully",
        error: null,
      })

      setTimeout(() => {
        set({ syncStatus: "Connected" })
      }, 2000)
    } catch (error) {
      console.error("❌ Error adding mark:", error)
      set({
        error: `Failed to add mark: ${error}`,
        syncStatus: "Error",
      })
    }
  },

  updateMark: async (id, updates) => {
    try {
      set({ syncStatus: "Updating mark..." })

      await firebaseSync.updateItem("marks", id, updates)

      console.log("✅ Mark updated:", id)
      set({
        syncStatus: "Mark updated successfully",
        error: null,
      })

      setTimeout(() => {
        set({ syncStatus: "Connected" })
      }, 2000)
    } catch (error) {
      console.error("❌ Error updating mark:", error)
      set({
        error: `Failed to update mark: ${error}`,
        syncStatus: "Error",
      })
    }
  },

  deleteMark: async (id) => {
    try {
      set({ syncStatus: "Deleting mark..." })

      await firebaseSync.deleteItem("marks", id)

      console.log("✅ Mark deleted:", id)
      set({
        syncStatus: "Mark deleted successfully",
        error: null,
      })

      setTimeout(() => {
        set({ syncStatus: "Connected" })
      }, 2000)
    } catch (error) {
      console.error("❌ Error deleting mark:", error)
      set({
        error: `Failed to delete mark: ${error}`,
        syncStatus: "Error",
      })
    }
  },

  forceSync: async () => {
    try {
      set({
        syncStatus: "Force syncing...",
        isLoading: true,
      })

      await firebaseSync.forceSync()

      console.log("✅ Force sync completed")
      set({
        syncStatus: "Sync completed",
        isLoading: false,
        error: null,
        lastSyncTime: new Date().toLocaleTimeString(),
      })

      setTimeout(() => {
        set({ syncStatus: "Connected" })
      }, 2000)
    } catch (error) {
      console.error("❌ Force sync failed:", error)
      set({
        error: `Sync failed: ${error}`,
        syncStatus: "Sync failed",
        isLoading: false,
      })
    }
  },

  clearError: () => {
    set({ error: null })
  },
}))
