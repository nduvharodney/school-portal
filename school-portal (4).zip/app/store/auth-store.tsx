"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

interface User {
  username: string
  password: string
  role: "teacher" | "admin"
}

interface AuthStore {
  users: User[]
  validateUser: (username: string, password: string) => User | null
  updatePassword: (role: string, currentPassword: string, newPassword: string) => boolean
  addUser: (username: string, password: string, role: "teacher" | "admin") => boolean
  updateUserPassword: (username: string, newPassword: string) => void
  deleteUser: (username: string) => void
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      users: [
        { username: "teacher", password: "teacher123", role: "teacher" },
        { username: "admin", password: "admin123", role: "admin" },
      ],

      validateUser: (username, password) => {
        const { users } = get()
        return users.find((user) => user.username === username && user.password === password) || null
      },

      updatePassword: (role, currentPassword, newPassword) => {
        const { users } = get()
        const userIndex = users.findIndex((user) => user.role === role)

        if (userIndex === -1 || users[userIndex].password !== currentPassword) {
          return false
        }

        set((state) => ({
          users: state.users.map((user, index) => (index === userIndex ? { ...user, password: newPassword } : user)),
        }))

        return true
      },

      addUser: (username, password, role) => {
        const { users } = get()

        if (users.some((user) => user.username === username)) {
          return false
        }

        set((state) => ({
          users: [...state.users, { username, password, role }],
        }))

        return true
      },

      updateUserPassword: (username, newPassword) => {
        set((state) => ({
          users: state.users.map((user) => (user.username === username ? { ...user, password: newPassword } : user)),
        }))
      },

      deleteUser: (username) => {
        set((state) => ({
          users: state.users.filter((user) => user.username !== username),
        }))
      },
    }),
    {
      name: "auth-store",
    },
  ),
)
