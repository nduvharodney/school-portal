"use client"

import { create } from "zustand"
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, orderBy, getDocs } from "firebase/firestore"
import { db } from "../lib/firebase"

interface Student {
  id: string
  firstName: string
  lastName: string
  fullName: string
  username: string
  password: string
  dateOfBirth: string
  gender: string
  contactNumber: string
  address: string
  form: string
  guardianFirstName: string
  guardianLastName: string
  relationship: string
  guardianIdNo: string
  guardianContact: string
  guardianAddress: string
  profileImage: string
  teacherComment?: string
  headComment?: string
  pastorComment?: string
  createdAt: string
  cloudId?: string
}

interface Mark {
  id: string
  studentId: string
  year: string
  session: string
  subject: string
  mark: number
  grade: string
  comment: string
  createdAt: string
  cloudId?: string
}

interface CloudStudentStore {
  students: Student[]
  marks: Mark[]
  isOnline: boolean
  isSyncing: boolean
  lastSyncTime: string

  // Student operations
  addStudent: (student: Omit<Student, "id" | "cloudId">) => Promise<void>
  updateStudent: (studentId: string, updates: Partial<Student>) => Promise<void>
  deleteStudent: (studentId: string) => Promise<void>

  // Mark operations
  addMark: (studentId: string, mark: Omit<Mark, "id" | "studentId" | "cloudId">) => Promise<void>
  updateMark: (markId: string, updates: Partial<Mark>) => Promise<void>
  deleteMark: (markId: string) => Promise<void>

  // Comment operations
  updateTeacherComment: (studentId: string, comment: string) => Promise<void>
  updateHeadComment: (studentId: string, comment: string) => Promise<void>
  updatePastorComment: (studentId: string, comment: string) => Promise<void>

  // Sync operations
  initializeSync: () => void
  forcSync: () => Promise<void>
  setOnlineStatus: (status: boolean) => void
}

export const useCloudStudentStore = create<CloudStudentStore>((set, get) => ({
  students: [],
  marks: [],
  isOnline: typeof window !== "undefined" ? navigator.onLine : false,
  isSyncing: false,
  lastSyncTime: "",

  // Initialize real-time sync
  initializeSync: () => {
    console.log("🔄 Initializing real-time sync...")

    // Listen to students collection
    const studentsQuery = query(collection(db, "students"), orderBy("createdAt", "desc"))
    const unsubscribeStudents = onSnapshot(
      studentsQuery,
      (snapshot) => {
        const students: Student[] = []
        snapshot.forEach((doc) => {
          students.push({
            ...(doc.data() as Omit<Student, "id" | "cloudId">),
            id: doc.data().id || doc.id,
            cloudId: doc.id,
          })
        })

        console.log(`📚 Synced ${students.length} students from cloud`)
        set({
          students,
          lastSyncTime: new Date().toLocaleString(),
          isSyncing: false,
        })
      },
      (error) => {
        console.error("❌ Error syncing students:", error)
        set({ isSyncing: false })
      },
    )

    // Listen to marks collection
    const marksQuery = query(collection(db, "marks"), orderBy("createdAt", "desc"))
    const unsubscribeMarks = onSnapshot(
      marksQuery,
      (snapshot) => {
        const marks: Mark[] = []
        snapshot.forEach((doc) => {
          marks.push({
            ...(doc.data() as Omit<Mark, "id" | "cloudId">),
            id: doc.data().id || doc.id,
            cloudId: doc.id,
          })
        })

        console.log(`📊 Synced ${marks.length} marks from cloud`)
        set({
          marks,
          lastSyncTime: new Date().toLocaleString(),
          isSyncing: false,
        })
      },
      (error) => {
        console.error("❌ Error syncing marks:", error)
        set({ isSyncing: false })
      },
    )

    // Monitor online status
    if (typeof window !== "undefined") {
      const handleOnline = () => {
        console.log("🌐 Device is online")
        set({ isOnline: true })
      }

      const handleOffline = () => {
        console.log("📴 Device is offline")
        set({ isOnline: false })
      }

      window.addEventListener("online", handleOnline)
      window.addEventListener("offline", handleOffline)

      // Cleanup function
      return () => {
        unsubscribeStudents()
        unsubscribeMarks()
        window.removeEventListener("online", handleOnline)
        window.removeEventListener("offline", handleOffline)
      }
    }
  },

  // Add student to cloud
  addStudent: async (studentData) => {
    set({ isSyncing: true })
    try {
      const student = {
        ...studentData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      }

      console.log("➕ Adding student to cloud:", student.fullName)
      const docRef = await addDoc(collection(db, "students"), student)
      console.log("✅ Student added to cloud with ID:", docRef.id)
    } catch (error) {
      console.error("❌ Error adding student to cloud:", error)
      // Fallback to local storage if cloud fails
      set((state) => ({
        students: [
          { ...studentData, id: Date.now().toString(), createdAt: new Date().toISOString() },
          ...state.students,
        ],
        isSyncing: false,
      }))
      throw error
    }
  },

  // Update student in cloud
  updateStudent: async (studentId, updates) => {
    set({ isSyncing: true })
    try {
      const { students } = get()
      const student = students.find((s) => s.id === studentId)

      if (student?.cloudId) {
        console.log("📝 Updating student in cloud:", studentId)
        await updateDoc(doc(db, "students", student.cloudId), updates)
        console.log("✅ Student updated in cloud")
      }
    } catch (error) {
      console.error("❌ Error updating student in cloud:", error)
      set({ isSyncing: false })
      throw error
    }
  },

  // Delete student from cloud
  deleteStudent: async (studentId) => {
    set({ isSyncing: true })
    try {
      const { students, marks } = get()
      const student = students.find((s) => s.id === studentId)

      if (student?.cloudId) {
        console.log("🗑️ Deleting student from cloud:", studentId)
        await deleteDoc(doc(db, "students", student.cloudId))

        // Delete associated marks
        const studentMarks = marks.filter((m) => m.studentId === studentId)
        for (const mark of studentMarks) {
          if (mark.cloudId) {
            await deleteDoc(doc(db, "marks", mark.cloudId))
          }
        }

        console.log("✅ Student and marks deleted from cloud")
      }
    } catch (error) {
      console.error("❌ Error deleting student from cloud:", error)
      set({ isSyncing: false })
      throw error
    }
  },

  // Add mark to cloud
  addMark: async (studentId, markData) => {
    set({ isSyncing: true })
    try {
      const mark = {
        ...markData,
        id: Date.now().toString(),
        studentId,
        createdAt: new Date().toISOString(),
      }

      console.log("➕ Adding mark to cloud:", mark.subject, "for student", studentId)

      // Remove existing mark for same student/subject/term/year
      const { marks } = get()
      const existingMark = marks.find(
        (m) =>
          m.studentId === studentId &&
          m.subject === markData.subject &&
          m.year === markData.year &&
          m.session === markData.session,
      )

      if (existingMark?.cloudId) {
        console.log("🔄 Updating existing mark in cloud")
        await updateDoc(doc(db, "marks", existingMark.cloudId), mark)
      } else {
        console.log("➕ Adding new mark to cloud")
        const docRef = await addDoc(collection(db, "marks"), mark)
        console.log("✅ Mark added to cloud with ID:", docRef.id)
      }
    } catch (error) {
      console.error("❌ Error adding mark to cloud:", error)
      set({ isSyncing: false })
      throw error
    }
  },

  // Update mark in cloud
  updateMark: async (markId, updates) => {
    set({ isSyncing: true })
    try {
      const { marks } = get()
      const mark = marks.find((m) => m.id === markId)

      if (mark?.cloudId) {
        console.log("📝 Updating mark in cloud:", markId)
        await updateDoc(doc(db, "marks", mark.cloudId), updates)
        console.log("✅ Mark updated in cloud")
      }
    } catch (error) {
      console.error("❌ Error updating mark in cloud:", error)
      set({ isSyncing: false })
      throw error
    }
  },

  // Delete mark from cloud
  deleteMark: async (markId) => {
    set({ isSyncing: true })
    try {
      const { marks } = get()
      const mark = marks.find((m) => m.id === markId)

      if (mark?.cloudId) {
        console.log("🗑️ Deleting mark from cloud:", markId)
        await deleteDoc(doc(db, "marks", mark.cloudId))
        console.log("✅ Mark deleted from cloud")
      }
    } catch (error) {
      console.error("❌ Error deleting mark from cloud:", error)
      set({ isSyncing: false })
      throw error
    }
  },

  // Update teacher comment
  updateTeacherComment: async (studentId, comment) => {
    await get().updateStudent(studentId, { teacherComment: comment })
  },

  // Update head comment
  updateHeadComment: async (studentId, comment) => {
    await get().updateStudent(studentId, { headComment: comment })
  },

  // Update pastor comment
  updatePastorComment: async (studentId, comment) => {
    await get().updateStudent(studentId, { pastorComment: comment })
  },

  // Force sync
  forcSync: async () => {
    set({ isSyncing: true })
    try {
      console.log("🔄 Force syncing data...")

      // Re-fetch all data
      const studentsSnapshot = await getDocs(query(collection(db, "students"), orderBy("createdAt", "desc")))
      const marksSnapshot = await getDocs(query(collection(db, "marks"), orderBy("createdAt", "desc")))

      const students: Student[] = []
      studentsSnapshot.forEach((doc) => {
        students.push({
          ...(doc.data() as Omit<Student, "id" | "cloudId">),
          id: doc.data().id || doc.id,
          cloudId: doc.id,
        })
      })

      const marks: Mark[] = []
      marksSnapshot.forEach((doc) => {
        marks.push({
          ...(doc.data() as Omit<Mark, "id" | "cloudId">),
          id: doc.data().id || doc.id,
          cloudId: doc.id,
        })
      })

      set({
        students,
        marks,
        lastSyncTime: new Date().toLocaleString(),
        isSyncing: false,
      })

      console.log("✅ Force sync completed")
    } catch (error) {
      console.error("❌ Error during force sync:", error)
      set({ isSyncing: false })
      throw error
    }
  },

  // Set online status
  setOnlineStatus: (status) => {
    set({ isOnline: status })
  },
}))
