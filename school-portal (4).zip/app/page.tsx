"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, FileText, UserPlus, Menu, X } from "lucide-react"
import NewStudent from "./components/new-student"
import EnterMarks from "./components/enter-marks"
import Reports from "./components/reports"
import ClassTeacher from "./components/class-teacher"
import Login from "./components/login"
import Settings from "./components/settings"
import ManageStudents from "./components/manage-students"
import StudentLogin from "./components/student-login"
import StudentReports from "./components/student-reports"
import { useUniversalStudentStore } from "./store/universal-student-store"
import { useAuthStore } from "./store/auth-store"
import UniversalSyncStatus from "./components/universal-sync-status"

export default function SchoolPortal() {
  const [currentView, setCurrentView] = useState("home")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { user, userType, setIsAuthenticated, setUserRole } = useAuthStore()
  const { students, marks, users, initializeStore } = useUniversalStudentStore()
  const [showStudentPortal, setShowStudentPortal] = useState(false)
  const [loggedInStudent, setLoggedInStudent] = useState(null)

  useEffect(() => {
    // Initialize the universal store when the app loads
    initializeStore()

    const urlParams = new URLSearchParams(window.location.search)
    const encodedData = urlParams.get("data")

    if (encodedData) {
      try {
        const data = JSON.parse(atob(encodedData))

        if (data.students && data.marks && data.users) {
          // Import to stores
          useUniversalStudentStore.setState({
            students: data.students,
            marks: data.marks,
          })

          useAuthStore.setState({
            users: data.users,
          })

          alert(`Data imported successfully from shared link!
    - ${data.students.length} students
    - ${data.marks.length} marks  
    - ${data.users.length} users
    - Export date: ${new Date(data.exportDate).toLocaleString()}`)

          // Clean URL
          window.history.replaceState({}, document.title, window.location.pathname)
        }
      } catch (err) {
        console.error("Failed to import data from URL:", err)
      }
    }
  }, [initializeStore])

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center">
            <img src="/images/school-logo.png" alt="School Logo" className="w-20 h-20 mx-auto mb-4 object-contain" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">ELIM CHRISTAIN COLLEGE</h1>
            <p className="text-gray-600">Student Portal System</p>
          </div>

          {userType === "student" ? <StudentLogin /> : <Login />}

          <div className="mt-8">
            <UniversalSyncStatus />
          </div>
        </div>
      </div>
    )
  }

  if (userType === "student" && !loggedInStudent) {
    return <StudentLogin onLogin={setLoggedInStudent} onBackToMain={() => setShowStudentPortal(false)} />
  }

  if (loggedInStudent) {
    return (
      <StudentReports
        student={loggedInStudent}
        onLogout={() => {
          setLoggedInStudent(null)
          setShowStudentPortal(false)
        }}
      />
    )
  }

  const renderContent = () => {
    switch (currentView) {
      case "new-student":
        return <NewStudent />
      case "enter-marks":
        return <EnterMarks />
      case "reports":
        return <Reports />
      case "class-teacher":
        return <ClassTeacher />
      case "settings":
        return <Settings userRole={userType} />
      case "manage-students":
        return <ManageStudents />
      default:
        return (
          <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800 p-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-8">
                <h1 className="text-4xl font-bold text-white mb-2">ELIM CHRISTAIN COLLEGE</h1>
                <p className="text-blue-200 text-lg">School Management Portal</p>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                <Card
                  className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer"
                  onClick={() => setCurrentView("new-student")}
                >
                  <CardHeader className="text-center">
                    <UserPlus className="w-12 h-12 text-white mx-auto mb-2" />
                    <CardTitle className="text-white">New Students</CardTitle>
                    <CardDescription className="text-blue-200">Register new students to the system</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">Add Student</Button>
                  </CardContent>
                </Card>

                <Card
                  className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer"
                  onClick={() => setCurrentView("enter-marks")}
                >
                  <CardHeader className="text-center">
                    <FileText className="w-12 h-12 text-white mx-auto mb-2" />
                    <CardTitle className="text-white">Enter Marks</CardTitle>
                    <CardDescription className="text-blue-200">Input student marks and grades</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">Enter Marks</Button>
                  </CardContent>
                </Card>

                <Card
                  className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer"
                  onClick={() => setCurrentView("reports")}
                >
                  <CardHeader className="text-center">
                    <Users className="w-12 h-12 text-white mx-auto mb-2" />
                    <CardTitle className="text-white">Reports</CardTitle>
                    <CardDescription className="text-blue-200">View and print student reports</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">View Reports</Button>
                  </CardContent>
                </Card>
                <Card
                  className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer"
                  onClick={() => setCurrentView("manage-students")}
                >
                  <CardHeader className="text-center">
                    <Users className="w-12 h-12 text-white mx-auto mb-2" />
                    <CardTitle className="text-white">Manage Students</CardTitle>
                    <CardDescription className="text-blue-200">View, edit, and delete student records</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">Manage Students</Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-800">
      {/* Mobile Menu Button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="bg-white/10 border-white/20 text-white"
        >
          {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </Button>
      </div>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-purple-800/90 backdrop-blur-sm transform transition-transform duration-300 ease-in-out ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}
      >
        <div className="p-6">
          <h2 className="text-white text-xl font-bold mb-6">Navigation</h2>
          <nav className="space-y-2">
            <Button
              variant={currentView === "home" ? "secondary" : "ghost"}
              className="w-full justify-start text-white hover:bg-white/10"
              onClick={() => {
                setCurrentView("home")
                setSidebarOpen(false)
              }}
            >
              Dashboard
            </Button>
            <Button
              variant={currentView === "new-student" ? "secondary" : "ghost"}
              className="w-full justify-start text-white hover:bg-white/10"
              onClick={() => {
                setCurrentView("new-student")
                setSidebarOpen(false)
              }}
            >
              New Student
            </Button>
            <Button
              variant={currentView === "enter-marks" ? "secondary" : "ghost"}
              className="w-full justify-start text-white hover:bg-white/10"
              onClick={() => {
                setCurrentView("enter-marks")
                setSidebarOpen(false)
              }}
            >
              Enter Marks
            </Button>
            <Button
              variant={currentView === "reports" ? "secondary" : "ghost"}
              className="w-full justify-start text-white hover:bg-white/10"
              onClick={() => {
                setCurrentView("reports")
                setSidebarOpen(false)
              }}
            >
              Reports
            </Button>
            <Button
              variant={currentView === "manage-students" ? "secondary" : "ghost"}
              className="w-full justify-start text-white hover:bg-white/10"
              onClick={() => {
                setCurrentView("manage-students")
                setSidebarOpen(false)
              }}
            >
              Manage Students
            </Button>
            {userType === "teacher" && (
              <Button
                variant={currentView === "class-teacher" ? "secondary" : "ghost"}
                className="w-full justify-start text-white hover:bg-white/10"
                onClick={() => {
                  setCurrentView("class-teacher")
                  setSidebarOpen(false)
                }}
              >
                Class Teacher
              </Button>
            )}
            <Button
              variant={currentView === "settings" ? "secondary" : "ghost"}
              className="w-full justify-start text-white hover:bg-white/10"
              onClick={() => {
                setCurrentView("settings")
                setSidebarOpen(false)
              }}
            >
              Settings
            </Button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:ml-64">{renderContent()}</div>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
    </div>
  )
}
